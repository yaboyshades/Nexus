"""
Unit tests for the world agent
"""
import unittest
from unittest.mock import AsyncMock, patch
import sys
import os
import random

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.world_agent import WorldAgent

class TestWorldAgent(unittest.TestCase):
    """Test cases for the World Agent class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.agent = WorldAgent("TestWorldAgent")
        
        # Sample game state for testing
        self.game_state = {
            "current_location": {
                "id": "loc_1",
                "name": "Test Location",
                "npcs": [
                    {
                        "id": "npc_1",
                        "name": "Test NPC"
                    }
                ]
            },
            "locations": {
                "loc_1": {
                    "id": "loc_1",
                    "name": "Test Location",
                    "exits": {
                        "north": "loc_2"
                    }
                }
            }
        }
    
    @patch('random.choice')
    @patch('random.random')
    async def test_generate_location(self, mock_random, mock_choice):
        """Test generating a new location"""
        # Set up mocks
        mock_choice.side_effect = ["Mystic Forest", "A dense forest with towering trees and dappled sunlight."]
        mock_random.return_value = 0.5  # Above monster threshold
        
        # Test input
        input_data = {
            "generation_request": {
                "type": "location",
                "location_id": "loc_2",
                "direction_from": "loc_1",
                "direction": "north"
            },
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("game_state_changes", result)
        self.assertIn("locations", result["game_state_changes"])
        self.assertIn("loc_2", result["game_state_changes"]["locations"])
        
        # Check location details
        new_location = result["game_state_changes"]["locations"]["loc_2"]
        self.assertEqual(new_location["id"], "loc_2")
        self.assertEqual(new_location["name"], "Mystic Forest")
        self.assertEqual(new_location["description"], "A dense forest with towering trees and dappled sunlight.")
        
        # Check exit back to original location
        self.assertIn("exits", new_location)
        self.assertIn("south", new_location["exits"])
        self.assertEqual(new_location["exits"]["south"], "loc_1")
    
    @patch('random.choice')
    async def test_generate_dialogue(self, mock_choice):
        """Test generating NPC dialogue"""
        # Set up mocks
        mock_choice.return_value = "That reminds me of a story..."
        
        # Test input
        input_data = {
            "generation_request": {
                "type": "npc_dialogue",
                "npc_id": "npc_1",
                "npc_name": "Test NPC",
                "player_dialogue": "Tell me a story"
            },
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("game_state_changes", result)
        self.assertIn("current_location", result["game_state_changes"])
        self.assertIn("npcs", result["game_state_changes"]["current_location"])
        
        # Check dialogue was added
        npcs = result["game_state_changes"]["current_location"]["npcs"]
        npc = next((n for n in npcs if n["id"] == "npc_1"), None)
        self.assertIsNotNone(npc)
        self.assertIn("dialogue_options", npc)
        self.assertGreater(len(npc["dialogue_options"]), 0)
        self.assertEqual(npc["dialogue_options"][-1]["text"], "That reminds me of a story...")
    
    async def test_unknown_generation_type(self):
        """Test handling unknown generation type"""
        # Test input
        input_data = {
            "generation_request": {
                "type": "unknown_type"
            },
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertFalse(result["success"])
        self.assertIn("narrative_summary", result)
        self.assertIn("Unknown generation request type", result["narrative_summary"])

if __name__ == '__main__':
    unittest.main()
