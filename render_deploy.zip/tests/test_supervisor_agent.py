"""
Unit tests for the supervisor agent
"""
import unittest
from unittest.mock import AsyncMock, patch, MagicMock
import sys
import os

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.supervisor_agent import SupervisorAgent

class TestSupervisorAgent(unittest.TestCase):
    """Test cases for the Supervisor Agent class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.agent = SupervisorAgent("TestSupervisorAgent")
        
        # Create mock agents
        self.intent_agent = MagicMock()
        self.rule_agent = MagicMock()
        self.narrative_agent = MagicMock()
        self.world_agent = MagicMock()
        
        # Register mock agents
        self.agent.register_agent("intent", self.intent_agent)
        self.agent.register_agent("rule", self.rule_agent)
        self.agent.register_agent("narrative", self.narrative_agent)
        self.agent.register_agent("world", self.world_agent)
        
        # Set up async mocks
        self.intent_agent.process = AsyncMock()
        self.rule_agent.process = AsyncMock()
        self.narrative_agent.process = AsyncMock()
        self.world_agent.process = AsyncMock()
        
        # Sample game state for testing
        self.game_state = {
            "player_character": {
                "id": "pc_1",
                "name": "Test Character",
                "hp": 20,
                "max_hp": 20
            },
            "current_location": {
                "id": "loc_1",
                "name": "Test Location"
            }
        }
        
        # Initialize agent's game state
        self.agent.game_state = self.game_state
    
    async def test_process_successful_flow(self):
        """Test processing a successful flow through all agents"""
        # Set up mock returns
        self.intent_agent.process.return_value = {
            "success": True,
            "confidence": 0.9,
            "parsed_intent": {
                "action": "attack",
                "target_id": "monster_1",
                "target_name": "Test Monster"
            }
        }
        
        self.rule_agent.process.return_value = {
            "success": True,
            "game_state_changes": {
                "current_location": {
                    "monsters": [
                        {"id": "monster_1", "hp": 5, "max_hp": 15}
                    ]
                }
            },
            "narrative_summary": "You hit the monster for 10 damage.",
            "new_events": [],
            "world_generation_needed": False
        }
        
        self.narrative_agent.process.return_value = {
            "narrative": "You swing your sword at the Test Monster, landing a solid blow that deals 10 damage."
        }
        
        # Test input
        input_data = {
            "player_input": "attack the monster",
            "user_id": "user_1",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertEqual(result["response_type"], "narrative")
        self.assertEqual(result["message"], "You swing your sword at the Test Monster, landing a solid blow that deals 10 damage.")
        self.assertIn("game_state_update", result)
        
        # Verify agent calls
        self.intent_agent.process.assert_called_once()
        self.rule_agent.process.assert_called_once()
        self.narrative_agent.process.assert_called_once()
        self.world_agent.process.assert_not_called()
    
    async def test_process_with_world_generation(self):
        """Test processing a flow that requires world generation"""
        # Set up mock returns
        self.intent_agent.process.return_value = {
            "success": True,
            "confidence": 0.9,
            "parsed_intent": {
                "action": "move",
                "direction": "north"
            }
        }
        
        self.rule_agent.process.return_value = {
            "success": True,
            "game_state_changes": {
                "player_character": {
                    "current_location_id": "loc_2"
                }
            },
            "narrative_summary": "You move north.",
            "new_events": [],
            "world_generation_needed": True,
            "world_generation_request": {
                "type": "location",
                "location_id": "loc_2",
                "direction_from": "loc_1",
                "direction": "north"
            }
        }
        
        self.world_agent.process.return_value = {
            "success": True,
            "game_state_changes": {
                "locations": {
                    "loc_2": {
                        "id": "loc_2",
                        "name": "New Location",
                        "description": "A newly generated location."
                    }
                }
            },
            "narrative_summary": "A new area has been discovered."
        }
        
        self.narrative_agent.process.return_value = {
            "narrative": "You move north and discover a new area called New Location. A newly generated location."
        }
        
        # Test input
        input_data = {
            "player_input": "move north",
            "user_id": "user_1",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertEqual(result["response_type"], "narrative")
        self.assertEqual(result["message"], "You move north and discover a new area called New Location. A newly generated location.")
        self.assertIn("game_state_update", result)
        
        # Verify agent calls
        self.intent_agent.process.assert_called_once()
        self.rule_agent.process.assert_called_once()
        self.world_agent.process.assert_called_once()
        self.narrative_agent.process.assert_called_once()
    
    async def test_process_intent_failure(self):
        """Test processing when intent recognition fails"""
        # Set up mock returns
        self.intent_agent.process.return_value = {
            "success": False,
            "confidence": 0.3,
            "message": "I'm not sure what you mean. Could you rephrase that?"
        }
        
        # Test input
        input_data = {
            "player_input": "do something unclear",
            "user_id": "user_1",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertEqual(result["response_type"], "clarification")
        self.assertEqual(result["message"], "I'm not sure what you mean. Could you rephrase that?")
        
        # Verify agent calls
        self.intent_agent.process.assert_called_once()
        self.rule_agent.process.assert_not_called()
        self.world_agent.process.assert_not_called()
        self.narrative_agent.process.assert_not_called()
    
    async def test_process_missing_agent(self):
        """Test processing when a required agent is missing"""
        # Remove an agent
        self.agent.agents.pop("rule")
        
        # Set up mock returns
        self.intent_agent.process.return_value = {
            "success": True,
            "confidence": 0.9,
            "parsed_intent": {
                "action": "attack",
                "target_id": "monster_1",
                "target_name": "Test Monster"
            }
        }
        
        # Test input
        input_data = {
            "player_input": "attack the monster",
            "user_id": "user_1",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertIn("error", result)
        self.assertEqual(result["error"], "Rule Agent not registered")
        
        # Verify agent calls
        self.intent_agent.process.assert_called_once()
        self.rule_agent.process.assert_not_called()
        self.world_agent.process.assert_not_called()
        self.narrative_agent.process.assert_not_called()
    
    def test_update_game_state(self):
        """Test updating the game state"""
        # Initial game state
        self.agent.game_state = {
            "player_character": {
                "hp": 20,
                "inventory": ["sword"]
            },
            "current_location": {
                "monsters": [
                    {"id": "monster_1", "hp": 15}
                ]
            }
        }
        
        # Changes to apply
        changes = {
            "player_character": {
                "hp": 15,
                "inventory": ["sword", "potion"]
            },
            "current_location": {
                "monsters": [
                    {"id": "monster_1", "hp": 10}
                ]
            }
        }
        
        # Update game state
        self.agent._update_game_state(changes)
        
        # Verify updates
        self.assertEqual(self.agent.game_state["player_character"]["hp"], 15)
        self.assertEqual(self.agent.game_state["player_character"]["inventory"], ["sword", "potion"])
        self.assertEqual(self.agent.game_state["current_location"]["monsters"][0]["hp"], 10)
    
    def test_get_frontend_game_state(self):
        """Test getting frontend game state"""
        # Set up game state
        self.agent.game_state = {
            "player_character": {
                "name": "Test Character",
                "race": "Human",
                "class": "Fighter",
                "level": 3,
                "hp": 25,
                "max_hp": 30,
                "ac": 16,
                "conditions": ["poisoned"],
                "inventory": ["sword", "shield"]
            },
            "current_location": {
                "name": "Dungeon",
                "description": "A dark dungeon."
            },
            "active_combat": {
                "round": 2,
                "current_turn": "pc_1"
            }
        }
        
        # Get frontend game state
        frontend_state = self.agent._get_frontend_game_state()
        
        # Verify frontend state
        self.assertIn("player_character", frontend_state)
        self.assertEqual(frontend_state["player_character"]["name"], "Test Character")
        self.assertEqual(frontend_state["player_character"]["race"], "Human")
        self.assertEqual(frontend_state["player_character"]["class"], "Fighter")
        self.assertEqual(frontend_state["player_character"]["level"], 3)
        self.assertEqual(frontend_state["player_character"]["hp"], 25)
        self.assertEqual(frontend_state["player_character"]["max_hp"], 30)
        self.assertEqual(frontend_state["player_character"]["ac"], 16)
        self.assertEqual(frontend_state["player_character"]["conditions"], ["poisoned"])
        
        self.assertIn("current_location", frontend_state)
        self.assertEqual(frontend_state["current_location"]["name"], "Dungeon")
        self.assertEqual(frontend_state["current_location"]["description"], "A dark dungeon.")
        
        self.assertTrue(frontend_state["in_combat"])
        self.assertIn("combat", frontend_state)
        self.assertEqual(frontend_state["combat"]["round"], 2)
        self.assertEqual(frontend_state["combat"]["current_turn"], "pc_1")

if __name__ == '__main__':
    unittest.main()
