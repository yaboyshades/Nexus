"""
Unit tests for the intent agent
"""
import unittest
from unittest.mock import AsyncMock, patch
import sys
import os

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.intent_agent import IntentAgent

class TestIntentAgent(unittest.TestCase):
    """Test cases for the Intent Agent class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.agent = IntentAgent("TestIntentAgent")
        
        # Sample game state for testing
        self.game_state = {
            "current_location": {
                "npcs": [
                    {"id": "npc_1", "name": "merchant"}
                ],
                "monsters": [
                    {"id": "monster_1", "name": "goblin"}
                ],
                "items": [
                    {"id": "item_1", "name": "sword"}
                ]
            },
            "player_character": {
                "known_spells": [
                    {"id": "spell_1", "name": "fireball"}
                ]
            }
        }
    
    @patch('agents.intent_agent.IntentAgent._extract_target')
    @patch('agents.intent_agent.IntentAgent._extract_spell')
    @patch('agents.intent_agent.IntentAgent._extract_direction')
    async def test_process_attack_command(self, mock_extract_direction, mock_extract_spell, mock_extract_target):
        """Test processing an attack command"""
        # Set up mocks
        mock_extract_target.return_value = {"id": "monster_1", "name": "goblin"}
        
        # Test input
        input_data = {
            "player_input": "attack goblin",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertGreaterEqual(result["confidence"], 0.8)
        self.assertEqual(result["parsed_intent"]["action"], "attack")
        self.assertEqual(result["parsed_intent"]["target_id"], "monster_1")
        self.assertEqual(result["parsed_intent"]["target_name"], "goblin")
    
    @patch('agents.intent_agent.IntentAgent._extract_target')
    @patch('agents.intent_agent.IntentAgent._extract_spell')
    @patch('agents.intent_agent.IntentAgent._extract_direction')
    async def test_process_talk_command(self, mock_extract_direction, mock_extract_spell, mock_extract_target):
        """Test processing a talk command"""
        # Set up mocks
        mock_extract_target.return_value = {"id": "npc_1", "name": "merchant"}
        
        # Test input
        input_data = {
            "player_input": "talk to merchant",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertGreaterEqual(result["confidence"], 0.8)
        self.assertEqual(result["parsed_intent"]["action"], "talk")
        self.assertEqual(result["parsed_intent"]["target_id"], "npc_1")
        self.assertEqual(result["parsed_intent"]["target_name"], "merchant")
    
    @patch('agents.intent_agent.IntentAgent._extract_target')
    @patch('agents.intent_agent.IntentAgent._extract_spell')
    @patch('agents.intent_agent.IntentAgent._extract_direction')
    async def test_process_cast_spell_command(self, mock_extract_direction, mock_extract_spell, mock_extract_target):
        """Test processing a cast spell command"""
        # Set up mocks
        mock_extract_spell.return_value = {"id": "spell_1", "name": "fireball"}
        mock_extract_target.return_value = {"id": "monster_1", "name": "goblin"}
        
        # Test input
        input_data = {
            "player_input": "cast fireball at goblin",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertGreaterEqual(result["confidence"], 0.8)
        self.assertEqual(result["parsed_intent"]["action"], "cast_spell")
        self.assertEqual(result["parsed_intent"]["spell_id"], "spell_1")
        self.assertEqual(result["parsed_intent"]["spell_name"], "fireball")
        self.assertEqual(result["parsed_intent"]["target_id"], "monster_1")
        self.assertEqual(result["parsed_intent"]["target_name"], "goblin")
    
    @patch('agents.intent_agent.IntentAgent._extract_target')
    @patch('agents.intent_agent.IntentAgent._extract_spell')
    @patch('agents.intent_agent.IntentAgent._extract_direction')
    async def test_process_move_command(self, mock_extract_direction, mock_extract_spell, mock_extract_target):
        """Test processing a move command"""
        # Set up mocks
        mock_extract_direction.return_value = "north"
        
        # Test input
        input_data = {
            "player_input": "move north",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertGreaterEqual(result["confidence"], 0.8)
        self.assertEqual(result["parsed_intent"]["action"], "move")
        self.assertEqual(result["parsed_intent"]["direction"], "north")
    
    @patch('agents.intent_agent.IntentAgent._extract_target')
    @patch('agents.intent_agent.IntentAgent._extract_spell')
    @patch('agents.intent_agent.IntentAgent._extract_direction')
    async def test_process_help_command(self, mock_extract_direction, mock_extract_spell, mock_extract_target):
        """Test processing a help command"""
        # Test input
        input_data = {
            "player_input": "help",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertEqual(result["confidence"], 1.0)
        self.assertEqual(result["parsed_intent"]["action"], "help")
    
    @patch('agents.intent_agent.IntentAgent._extract_target')
    @patch('agents.intent_agent.IntentAgent._extract_spell')
    @patch('agents.intent_agent.IntentAgent._extract_direction')
    async def test_process_unknown_command(self, mock_extract_direction, mock_extract_spell, mock_extract_target):
        """Test processing an unknown command"""
        # Test input
        input_data = {
            "player_input": "dance around",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertLess(result["confidence"], 0.7)
        self.assertEqual(result["parsed_intent"]["action"], "general")

if __name__ == '__main__':
    unittest.main()
