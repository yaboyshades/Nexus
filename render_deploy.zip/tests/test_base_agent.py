"""
Unit tests for the base agent class
"""
import unittest
from unittest.mock import AsyncMock, patch
import sys
import os

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.base_agent import Agent

class TestBaseAgent(unittest.TestCase):
    """Test cases for the base Agent class"""
    
    def test_init(self):
        """Test agent initialization"""
        agent = MockAgent("TestAgent")
        self.assertEqual(agent.name, "TestAgent")
    
    @patch('agents.base_agent.Agent.process', new_callable=AsyncMock)
    async def test_process_abstract(self, mock_process):
        """Test that process method is abstract and must be implemented"""
        # Set up mock to return a value
        mock_process.return_value = {"result": "success"}
        
        # Create a mock agent
        agent = MockAgent("TestAgent")
        
        # Call process method
        result = await agent.process({"test": "data"})
        
        # Verify mock was called with correct arguments
        mock_process.assert_called_once_with({"test": "data"})
        
        # Verify result
        self.assertEqual(result, {"result": "success"})

class MockAgent(Agent):
    """Mock implementation of Agent for testing"""
    
    async def process(self, input_data):
        """Implement abstract method"""
        return {"result": "success"}

if __name__ == '__main__':
    unittest.main()
