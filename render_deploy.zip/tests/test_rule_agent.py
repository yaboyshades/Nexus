"""
Unit tests for the rule agent
"""
import unittest
from unittest.mock import AsyncMock, patch
import sys
import os
import random

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.rule_agent import RuleAgent

class TestRuleAgent(unittest.TestCase):
    """Test cases for the Rule Agent class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.agent = RuleAgent("TestRuleAgent")
        
        # Sample game state for testing
        self.game_state = {
            "player_character": {
                "id": "pc_1",
                "name": "Test Character",
                "attack_bonus": 5,
                "damage_dice": "1d8",
                "damage_bonus": 3,
                "hp": 20,
                "max_hp": 20,
                "inventory": []
            },
            "current_location": {
                "id": "loc_1",
                "name": "Test Location",
                "npcs": [
                    {
                        "id": "npc_1",
                        "name": "Test NPC",
                        "dialogue_options": [
                            {"text": "Hello, adventurer!"}
                        ]
                    }
                ],
                "monsters": [
                    {
                        "id": "monster_1",
                        "name": "Test Monster",
                        "hp": 15,
                        "max_hp": 15,
                        "ac": 12,
                        "xp_value": 100
                    }
                ],
                "items": [
                    {
                        "id": "item_1",
                        "name": "Test Item"
                    }
                ],
                "exits": {
                    "north": "loc_2"
                }
            }
        }
        
        # Sample parsed intent for testing
        self.attack_intent = {
            "action": "attack",
            "target_id": "monster_1",
            "target_name": "Test Monster",
            "parameters": {}
        }
        
        self.talk_intent = {
            "action": "talk",
            "target_id": "npc_1",
            "target_name": "Test NPC",
            "parameters": {
                "dialogue": "Hello there"
            }
        }
        
        self.examine_intent = {
            "action": "examine",
            "target_id": "loc_1",
            "target_name": "location",
            "parameters": {}
        }
        
        self.pick_up_intent = {
            "action": "pick_up_item",
            "target_id": "item_1",
            "target_name": "Test Item",
            "parameters": {}
        }
        
        self.move_intent = {
            "action": "move",
            "direction": "north",
            "parameters": {}
        }
        
        self.help_intent = {
            "action": "help",
            "parameters": {}
        }
    
    @patch('random.randint')
    async def test_resolve_attack_hit(self, mock_randint):
        """Test resolving an attack that hits"""
        # Set up mocks for dice rolls
        mock_randint.side_effect = [15, 5]  # Attack roll, damage roll
        
        # Test input
        input_data = {
            "parsed_intent": self.attack_intent,
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("game_state_changes", result)
        self.assertIn("narrative_summary", result)
        self.assertIn("hit with a", result["narrative_summary"])
        self.assertIn("dealing", result["narrative_summary"])
        
        # Check that monster HP was reduced
        monsters = result["game_state_changes"]["current_location"]["monsters"]
        monster = next((m for m in monsters if m["id"] == "monster_1"), None)
        self.assertIsNotNone(monster)
        self.assertLess(monster["hp"], 15)  # HP should be reduced
    
    @patch('random.randint')
    async def test_resolve_attack_miss(self, mock_randint):
        """Test resolving an attack that misses"""
        # Set up mocks for dice rolls
        mock_randint.return_value = 1  # Attack roll (will miss)
        
        # Test input
        input_data = {
            "parsed_intent": self.attack_intent,
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("narrative_summary", result)
        self.assertIn("miss", result["narrative_summary"])
    
    @patch('random.randint')
    async def test_resolve_attack_defeat(self, mock_randint):
        """Test resolving an attack that defeats the monster"""
        # Set up mocks for dice rolls
        mock_randint.side_effect = [20, 8]  # Critical hit, max damage
        
        # Modify monster HP to be low
        self.game_state["current_location"]["monsters"][0]["hp"] = 5
        
        # Test input
        input_data = {
            "parsed_intent": self.attack_intent,
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("narrative_summary", result)
        self.assertIn("defeated", result["narrative_summary"])
        
        # Check for defeat event
        self.assertGreater(len(result["new_events"]), 0)
        defeat_event = next((e for e in result["new_events"] if e["type"] == "MonsterDefeated"), None)
        self.assertIsNotNone(defeat_event)
        self.assertEqual(defeat_event["monster_id"], "monster_1")
        self.assertEqual(defeat_event["xp_amount"], 100)
    
    async def test_resolve_talk(self):
        """Test resolving a talk action"""
        # Test input
        input_data = {
            "parsed_intent": self.talk_intent,
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("narrative_summary", result)
        self.assertIn("speak to", result["narrative_summary"])
    
    async def test_resolve_examine(self):
        """Test resolving an examine action"""
        # Test input
        input_data = {
            "parsed_intent": self.examine_intent,
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("narrative_summary", result)
        self.assertIn("examine", result["narrative_summary"])
    
    async def test_resolve_pick_up_item(self):
        """Test resolving a pick up item action"""
        # Test input
        input_data = {
            "parsed_intent": self.pick_up_intent,
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("game_state_changes", result)
        self.assertIn("narrative_summary", result)
        self.assertIn("pick up", result["narrative_summary"])
        
        # Check that item was added to inventory
        self.assertIn("player_character", result["game_state_changes"])
        self.assertIn("inventory", result["game_state_changes"]["player_character"])
        inventory = result["game_state_changes"]["player_character"]["inventory"]
        self.assertEqual(len(inventory), 1)
        self.assertEqual(inventory[0]["id"], "item_1")
        
        # Check that item was removed from location
        self.assertIn("current_location", result["game_state_changes"])
        self.assertIn("items", result["game_state_changes"]["current_location"])
        items = result["game_state_changes"]["current_location"]["items"]
        self.assertEqual(len(items), 0)
    
    async def test_resolve_move(self):
        """Test resolving a move action"""
        # Test input
        input_data = {
            "parsed_intent": self.move_intent,
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("game_state_changes", result)
        self.assertIn("narrative_summary", result)
        self.assertIn("move north", result["narrative_summary"])
        
        # Check that player location was updated
        self.assertIn("player_character", result["game_state_changes"])
        self.assertEqual(result["game_state_changes"]["player_character"]["current_location_id"], "loc_2")
        
        # Check for world generation request
        self.assertTrue(result["world_generation_needed"])
        self.assertIn("world_generation_request", result)
        self.assertEqual(result["world_generation_request"]["type"], "location")
        self.assertEqual(result["world_generation_request"]["location_id"], "loc_2")
    
    async def test_resolve_help(self):
        """Test resolving a help action"""
        # Test input
        input_data = {
            "parsed_intent": self.help_intent,
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertTrue(result["success"])
        self.assertIn("narrative_summary", result)
        self.assertIn("commands", result["narrative_summary"])

if __name__ == '__main__':
    unittest.main()
