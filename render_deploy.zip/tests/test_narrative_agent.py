"""
Unit tests for the narrative agent
"""
import unittest
from unittest.mock import AsyncMock, patch
import sys
import os
import random

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.narrative_agent import NarrativeAgent

class TestNarrativeAgent(unittest.TestCase):
    """Test cases for the Narrative Agent class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.agent = NarrativeAgent("TestNarrativeAgent")
        
        # Sample game state for testing
        self.game_state = {
            "player_character": {
                "id": "pc_1",
                "name": "Test Character",
                "hp": 20,
                "max_hp": 20
            },
            "current_location": {
                "id": "loc_1",
                "name": "Test Location",
                "description": "A test location for unit testing.",
                "npcs": [
                    {
                        "id": "npc_1",
                        "name": "Test NPC",
                        "short_description": "A test NPC.",
                        "description": "A detailed description of the test NPC.",
                        "dialogue_options": [
                            {"text": "Hello, adventurer!"}
                        ]
                    }
                ],
                "monsters": [
                    {
                        "id": "monster_1",
                        "name": "Test Monster",
                        "short_description": "A test monster.",
                        "description": "A detailed description of the test monster.",
                        "hp": 15,
                        "max_hp": 15
                    }
                ],
                "items": [
                    {
                        "id": "item_1",
                        "name": "Test Item",
                        "short_description": "A test item.",
                        "description": "A detailed description of the test item."
                    }
                ],
                "exits": {
                    "north": "loc_2"
                }
            }
        }
        
        # Sample rule outcomes for testing
        self.attack_outcome = {
            "success": True,
            "narrative_summary": "You attack Test Monster. You hit with a 15 against AC 12, dealing 8 damage.",
            "new_events": []
        }
        
        self.attack_defeat_outcome = {
            "success": True,
            "narrative_summary": "You attack Test Monster. You hit with a 20 against AC 12, dealing 11 damage. Test Monster is defeated!",
            "new_events": [
                {
                    "type": "MonsterDefeated",
                    "monster_id": "monster_1",
                    "xp_amount": 100
                }
            ]
        }
        
        self.talk_outcome = {
            "success": True,
            "narrative_summary": "You speak to Test NPC.",
            "new_events": []
        }
        
        self.examine_outcome = {
            "success": True,
            "narrative_summary": "You examine your surroundings.",
            "new_events": []
        }
        
        self.cast_spell_outcome = {
            "success": True,
            "narrative_summary": "You cast Fireball at Test Monster, dealing 15 damage.",
            "new_events": []
        }
    
    @patch('random.choice')
    async def test_process_attack(self, mock_choice):
        """Test processing an attack narrative"""
        # Set up mocks
        mock_choice.return_value = " The monster recoils from your powerful strike."
        
        # Test input
        input_data = {
            "rule_outcome": self.attack_outcome,
            "parsed_intent": {
                "action": "attack",
                "target_id": "monster_1",
                "target_name": "Test Monster"
            },
            "player_input": "attack the monster",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertIn("narrative", result)
        self.assertIn("You attack Test Monster", result["narrative"])
        self.assertIn("hit with a 15", result["narrative"])
        self.assertIn("dealing 8 damage", result["narrative"])
    
    @patch('random.choice')
    async def test_process_attack_defeat(self, mock_choice):
        """Test processing an attack that defeats a monster"""
        # Set up mocks
        mock_choice.return_value = " With a final blow, Test Monster falls before you."
        
        # Test input
        input_data = {
            "rule_outcome": self.attack_defeat_outcome,
            "parsed_intent": {
                "action": "attack",
                "target_id": "monster_1",
                "target_name": "Test Monster"
            },
            "player_input": "attack the monster",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertIn("narrative", result)
        self.assertIn("You attack Test Monster", result["narrative"])
        self.assertIn("hit with a 20", result["narrative"])
        self.assertIn("Test Monster is defeated", result["narrative"])
        self.assertIn("falls before you", result["narrative"])
    
    @patch('random.choice')
    async def test_process_talk(self, mock_choice):
        """Test processing a talk narrative"""
        # Set up mocks
        mock_choice.return_value = "Hello, adventurer!"
        
        # Test input
        input_data = {
            "rule_outcome": self.talk_outcome,
            "parsed_intent": {
                "action": "talk",
                "target_id": "npc_1",
                "target_name": "Test NPC"
            },
            "player_input": "talk to the NPC",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertIn("narrative", result)
        self.assertIn("You speak to Test NPC", result["narrative"])
        self.assertIn("Test NPC says:", result["narrative"])
        self.assertIn("Hello, adventurer!", result["narrative"])
    
    async def test_process_examine_location(self):
        """Test processing an examine location narrative"""
        # Test input
        input_data = {
            "rule_outcome": self.examine_outcome,
            "parsed_intent": {
                "action": "examine",
                "target_id": "loc_1",
                "target_name": "location"
            },
            "player_input": "look around",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertIn("narrative", result)
        self.assertIn("You examine your surroundings", result["narrative"])
        self.assertIn("A test location for unit testing", result["narrative"])
        self.assertIn("You see the following people here:", result["narrative"])
        self.assertIn("Test NPC", result["narrative"])
        self.assertIn("You see the following creatures here:", result["narrative"])
        self.assertIn("Test Monster", result["narrative"])
        self.assertIn("You see the following items here:", result["narrative"])
        self.assertIn("Test Item", result["narrative"])
        self.assertIn("You can go in these directions:", result["narrative"])
        self.assertIn("north", result["narrative"])
    
    @patch('random.choice')
    async def test_process_cast_spell(self, mock_choice):
        """Test processing a cast spell narrative"""
        # Set up mocks
        mock_choice.return_value = " Arcane energy flows through your fingertips as you cast Fireball."
        
        # Test input
        input_data = {
            "rule_outcome": self.cast_spell_outcome,
            "parsed_intent": {
                "action": "cast_spell",
                "spell_id": "spell_1",
                "spell_name": "Fireball",
                "target_id": "monster_1",
                "target_name": "Test Monster"
            },
            "player_input": "cast fireball at the monster",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertIn("narrative", result)
        self.assertIn("You cast Fireball at Test Monster", result["narrative"])
        self.assertIn("dealing 15 damage", result["narrative"])
        self.assertIn("Arcane energy flows", result["narrative"])
    
    @patch('random.choice')
    async def test_process_general_action(self, mock_choice):
        """Test processing a general action"""
        # Set up mocks
        mock_choice.return_value = "The DM considers your action..."
        
        # Test input
        input_data = {
            "rule_outcome": {
                "success": True,
                "narrative_summary": "The DM considers your action."
            },
            "parsed_intent": {
                "action": "general",
                "text": "dance a jig"
            },
            "player_input": "dance a jig",
            "game_state": self.game_state
        }
        
        # Process input
        result = await self.agent.process(input_data)
        
        # Verify result
        self.assertIn("narrative", result)
        self.assertEqual(result["narrative"], "The DM considers your action...")

if __name__ == '__main__':
    unittest.main()
