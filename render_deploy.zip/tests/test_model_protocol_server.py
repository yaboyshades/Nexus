"""
Unit tests for the Model Protocol Server
"""
import unittest
from unittest.mock import AsyncMock, patch, MagicMock
import sys
import os
import json
import asyncio

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from model_protocol_server import (
    ModelProtocolServer, 
    OpenAIBackend, 
    AnthropicBackend, 
    LocalModelBackend,
    ResponseCache,
    get_model_server
)

class TestModelProtocolServer(unittest.TestCase):
    """Test cases for the Model Protocol Server"""
    
    def setUp(self):
        """Set up test fixtures"""
        # Create a test configuration
        self.test_config = {
            "default_backend": "test_backend",
            "cache_max_size": 10,
            "cache_ttl": 60,
            "backends": {
                "test_backend": {
                    "type": "local",
                    "model_path": "test_path"
                }
            }
        }
        
        # Create a server instance with the test configuration
        self.server = ModelProtocolServer(self.test_config)
        
        # Mock the backends
        self.server.backends = {
            "test_backend": MagicMock()
        }
        self.server.backends["test_backend"].generate = AsyncMock()
        self.server.backends["test_backend"].generate_with_json = AsyncMock()
    
    @patch('model_protocol_server._instance', None)
    def test_get_model_server(self):
        """Test getting the singleton instance"""
        # First call should create a new instance
        server1 = get_model_server()
        self.assertIsNotNone(server1)
        
        # Second call should return the same instance
        server2 = get_model_server()
        self.assertIs(server1, server2)
        
        # Call with config should still return the same instance
        server3 = get_model_server({"test": "config"})
        self.assertIs(server1, server3)
    
    def test_initialize_backends(self):
        """Test initializing backends from configuration"""
        # Create a server with multiple backends
        config = {
            "backends": {
                "openai": {
                    "type": "openai",
                    "api_key": "test_key",
                    "model": "test_model"
                },
                "anthropic": {
                    "type": "anthropic",
                    "api_key": "test_key",
                    "model": "test_model"
                },
                "local": {
                    "type": "local",
                    "model_path": "test_path"
                },
                "unknown": {
                    "type": "unknown"
                }
            }
        }
        
        server = ModelProtocolServer(config)
        
        # Check that backends were initialized
        self.assertIn("openai", server.backends)
        self.assertIsInstance(server.backends["openai"], OpenAIBackend)
        
        self.assertIn("anthropic", server.backends)
        self.assertIsInstance(server.backends["anthropic"], AnthropicBackend)
        
        self.assertIn("local", server.backends)
        self.assertIsInstance(server.backends["local"], LocalModelBackend)
        
        # Unknown backend should be ignored
        self.assertNotIn("unknown", server.backends)
    
    def test_get_backend(self):
        """Test getting a backend by name"""
        # Valid backend
        backend = self.server._get_backend("test_backend")
        self.assertEqual(backend, self.server.backends["test_backend"])
        
        # Default backend
        backend = self.server._get_backend()
        self.assertEqual(backend, self.server.backends["test_backend"])
        
        # Invalid backend
        with self.assertRaises(ValueError):
            self.server._get_backend("invalid_backend")
    
    def test_get_cache_key(self):
        """Test generating a cache key"""
        prompt = "test prompt"
        params = {"param1": "value1", "param2": "value2"}
        backend_name = "test_backend"
        
        key1 = self.server._get_cache_key(prompt, params, backend_name)
        
        # Same inputs should produce the same key
        key2 = self.server._get_cache_key(prompt, params, backend_name)
        self.assertEqual(key1, key2)
        
        # Different inputs should produce different keys
        key3 = self.server._get_cache_key("different prompt", params, backend_name)
        self.assertNotEqual(key1, key3)
        
        key4 = self.server._get_cache_key(prompt, {"different": "params"}, backend_name)
        self.assertNotEqual(key1, key4)
        
        key5 = self.server._get_cache_key(prompt, params, "different_backend")
        self.assertNotEqual(key1, key5)
    
    async def test_generate(self):
        """Test generating text"""
        # Set up mock return value
        self.server.backends["test_backend"].generate.return_value = "test response"
        
        # Test with default parameters
        response = await self.server.generate("test prompt")
        self.assertEqual(response, "test response")
        
        # Verify mock was called with correct arguments
        self.server.backends["test_backend"].generate.assert_called_with("test prompt", {})
        
        # Test with custom parameters
        params = {"temperature": 0.5}
        response = await self.server.generate("test prompt", params, "test_backend")
        self.assertEqual(response, "test response")
        
        # Verify mock was called with correct arguments
        self.server.backends["test_backend"].generate.assert_called_with("test prompt", params)
    
    async def test_generate_with_json(self):
        """Test generating JSON"""
        # Set up mock return value
        test_json = {"key": "value"}
        self.server.backends["test_backend"].generate_with_json.return_value = test_json
        
        # Test with default parameters
        schema = {"type": "object"}
        response = await self.server.generate_with_json("test prompt", schema)
        self.assertEqual(response, test_json)
        
        # Verify mock was called with correct arguments
        self.server.backends["test_backend"].generate_with_json.assert_called_with("test prompt", schema, {})
        
        # Test with custom parameters
        params = {"temperature": 0.5}
        response = await self.server.generate_with_json("test prompt", schema, params, "test_backend")
        self.assertEqual(response, test_json)
        
        # Verify mock was called with correct arguments
        self.server.backends["test_backend"].generate_with_json.assert_called_with("test prompt", schema, params)
    
    def test_store_and_get_context(self):
        """Test storing and retrieving context data"""
        context_id = "test_context"
        context_data = {"key": "value"}
        
        # Store context
        self.server.store_context(context_id, context_data)
        
        # Retrieve context
        retrieved_data = self.server.get_context(context_id)
        self.assertEqual(retrieved_data, context_data)
        
        # Non-existent context
        self.assertIsNone(self.server.get_context("non_existent"))
    
    def test_get_available_backends(self):
        """Test getting available backends"""
        backends = self.server.get_available_backends()
        self.assertEqual(backends, ["test_backend"])
    
    def test_get_backend_info(self):
        """Test getting backend info"""
        # Mock backend attributes
        self.server.backends["test_backend"].__class__.__name__ = "TestBackend"
        self.server.backends["test_backend"].model = "test_model"
        
        # Get info for specific backend
        info = self.server.get_backend_info("test_backend")
        self.assertEqual(info["name"], "test_backend")
        self.assertEqual(info["type"], "TestBackend")
        self.assertEqual(info["model"], "test_model")
        
        # Get info for default backend
        info = self.server.get_backend_info()
        self.assertEqual(info["name"], "test_backend")
    
    def test_clear_cache(self):
        """Test clearing the cache"""
        # Mock the cache
        self.server.cache = MagicMock()
        
        # Clear cache
        self.server.clear_cache()
        
        # Verify cache was cleared
        self.server.cache.clear.assert_called_once()

class TestResponseCache(unittest.TestCase):
    """Test cases for the Response Cache"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.cache = ResponseCache(max_size=3, ttl=1)  # Short TTL for testing
    
    def test_set_and_get(self):
        """Test setting and getting items"""
        # Set an item
        self.cache.set("key1", "value1")
        
        # Get the item
        value = self.cache.get("key1")
        self.assertEqual(value, "value1")
        
        # Get a non-existent item
        value = self.cache.get("non_existent")
        self.assertIsNone(value)
    
    def test_max_size(self):
        """Test max size limit"""
        # Fill the cache
        self.cache.set("key1", "value1")
        self.cache.set("key2", "value2")
        self.cache.set("key3", "value3")
        
        # All items should be present
        self.assertEqual(self.cache.get("key1"), "value1")
        self.assertEqual(self.cache.get("key2"), "value2")
        self.assertEqual(self.cache.get("key3"), "value3")
        
        # Add one more item (should evict the least recently used)
        self.cache.set("key4", "value4")
        
        # key1 should be evicted (least recently used)
        self.assertIsNone(self.cache.get("key1"))
        
        # Other items should still be present
        self.assertEqual(self.cache.get("key2"), "value2")
        self.assertEqual(self.cache.get("key3"), "value3")
        self.assertEqual(self.cache.get("key4"), "value4")
    
    def test_ttl(self):
        """Test time to live"""
        # Set an item
        self.cache.set("key1", "value1")
        
        # Item should be present initially
        self.assertEqual(self.cache.get("key1"), "value1")
        
        # Wait for TTL to expire
        import time
        time.sleep(2)  # Wait longer than TTL
        
        # Item should be expired
        self.assertIsNone(self.cache.get("key1"))
    
    def test_clear(self):
        """Test clearing the cache"""
        # Fill the cache
        self.cache.set("key1", "value1")
        self.cache.set("key2", "value2")
        
        # Clear the cache
        self.cache.clear()
        
        # All items should be gone
        self.assertIsNone(self.cache.get("key1"))
        self.assertIsNone(self.cache.get("key2"))

class TestOpenAIBackend(unittest.TestCase):
    """Test cases for the OpenAI Backend"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.backend = OpenAIBackend(api_key="", model="test_model")
    
    def test_mock_generate(self):
        """Test mock generation when no API key is provided"""
        # Test different prompt types
        self.assertIn("swing your sword", self.backend._mock_generate("attack the goblin"))
        self.assertIn("cast", self.backend._mock_generate("cast fireball"))
        self.assertIn("move", self.backend._mock_generate("move north"))
        self.assertIn("examine", self.backend._mock_generate("examine the room"))
        self.assertIn("merchant", self.backend._mock_generate("talk to the merchant"))
        self.assertIn("Dungeon Master", self.backend._mock_generate("do something else"))
    
    def test_mock_generate_json(self):
        """Test mock JSON generation when no API key is provided"""
        schema = {"type": "object", "properties": {"success": {"type": "boolean"}}}
        
        # Test different prompt types
        result = self.backend._mock_generate_json("intent: attack the goblin", schema)
        self.assertTrue(result["success"])
        self.assertEqual(result["parsed_intent"]["action"], "attack")
        
        result = self.backend._mock_generate_json("rule: attack the goblin", schema)
        self.assertTrue(result["success"])
        self.assertIn("narrative_summary", result)
        
        result = self.backend._mock_generate_json("narrative: attack the goblin", schema)
        self.assertIn("narrative", result)
        
        result = self.backend._mock_generate_json("world: generate location", schema)
        self.assertTrue(result["success"])
        self.assertIn("game_state_changes", result)
        
        # Test with unknown prompt type
        result = self.backend._mock_generate_json("unknown", schema)
        self.assertIn("mock value", str(result))

class TestAnthropicBackend(unittest.TestCase):
    """Test cases for the Anthropic Backend"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.backend = AnthropicBackend(api_key="", model="test_model")
    
    def test_mock_generate(self):
        """Test mock generation when no API key is provided"""
        # Test different prompt types
        self.assertIn("swing your sword", self.backend._mock_generate("attack the goblin"))
        self.assertIn("cast", self.backend._mock_generate("cast fireball"))
        self.assertIn("move", self.backend._mock_generate("move north"))
        self.assertIn("examine", self.backend._mock_generate("examine the room"))
        self.assertIn("merchant", self.backend._mock_generate("talk to the merchant"))
        self.assertIn("Dungeon Master", self.backend._mock_generate("do something else"))
    
    def test_mock_generate_json(self):
        """Test mock JSON generation when no API key is provided"""
        schema = {"type": "object", "properties": {"success": {"type": "boolean"}}}
        
        # Test different prompt types
        result = self.backend._mock_generate_json("intent: attack the goblin", schema)
        self.assertTrue(result["success"])
        self.assertEqual(result["parsed_intent"]["action"], "attack")
        
        result = self.backend._mock_generate_json("rule: attack the goblin", schema)
        self.assertTrue(result["success"])
        self.assertIn("narrative_summary", result)
        
        result = self.backend._mock_generate_json("narrative: attack the goblin", schema)
        self.assertIn("narrative", result)
        
        result = self.backend._mock_generate_json("world: generate location", schema)
        self.assertTrue(result["success"])
        self.assertIn("game_state_changes", result)
        
        # Test with unknown prompt type
        result = self.backend._mock_generate_json("unknown", schema)
        self.assertIn("mock value", str(result))

class TestLocalModelBackend(unittest.TestCase):
    """Test cases for the Local Model Backend"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.backend = LocalModelBackend(model_path="test_path")
    
    def test_mock_generate(self):
        """Test mock generation"""
        # Test different prompt types
        self.assertIn("swing your sword", self.backend._mock_generate("attack the goblin"))
        self.assertIn("cast", self.backend._mock_generate("cast fireball"))
        self.assertIn("move", self.backend._mock_generate("move north"))
        self.assertIn("examine", self.backend._mock_generate("examine the room"))
        self.assertIn("merchant", self.backend._mock_generate("talk to the merchant"))
        self.assertIn("Dungeon Master", self.backend._mock_generate("do something else"))
    
    def test_mock_generate_json(self):
        """Test mock JSON generation"""
        schema = {"type": "object", "properties": {"success": {"type": "boolean"}}}
        
        # Test different prompt types
        result = self.backend._mock_generate_json("intent: attack the goblin", schema)
        self.assertTrue(result["success"])
        self.assertEqual(result["parsed_intent"]["action"], "attack")
        
        result = self.backend._mock_generate_json("rule: attack the goblin", schema)
        self.assertTrue(result["success"])
        self.assertIn("narrative_summary", result)
        
        result = self.backend._mock_generate_json("narrative: attack the goblin", schema)
        self.assertIn("narrative", result)
        
        result = self.backend._mock_generate_json("world: generate location", schema)
        self.assertTrue(result["success"])
        self.assertIn("game_state_changes", result)
        
        # Test with unknown prompt type
        result = self.backend._mock_generate_json("unknown", schema)
        self.assertIn("mock value", str(result))

if __name__ == '__main__':
    unittest.main()
