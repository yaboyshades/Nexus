"""
Test script for Town Generator integration in Digital DM Game

This script tests the town generator, World Agent integration, and game state
model support for town data structures.
"""

import os
import sys
import json
import asyncio
import logging
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import town_generator
from agents.world_agent import WorldAgent
from models.game_models import GameState, Town, NPC, Building, Location

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('test_town_generator')

async def test_town_generator():
    """Test the town generator functionality"""
    logger.info("Testing town generator...")
    
    # Get town generator instance
    generator = town_generator.get_town_generator()
    
    # Test initial town generation
    logger.info("Testing initial town generation...")
    initial_town = await town_generator.generate_initial_town()
    
    logger.info(f"Generated initial town: {initial_town['name']}")
    logger.info(f"Town size: {initial_town['size']}")
    logger.info(f"Population: {initial_town['population']}")
    logger.info(f"Buildings: {len(initial_town['buildings'])}")
    logger.info(f"NPCs: {len(initial_town['npcs'])}")
    logger.info(f"Rumors: {len(initial_town['rumors'])}")
    
    # Test on-demand town generation
    logger.info("Testing on-demand town generation...")
    new_town = await generator.generate_town("test_town")
    
    logger.info(f"Generated new town: {new_town['name']}")
    logger.info(f"Town size: {new_town['size']}")
    logger.info(f"Population: {new_town['population']}")
    logger.info(f"Buildings: {len(new_town['buildings'])}")
    logger.info(f"NPCs: {len(new_town['npcs'])}")
    logger.info(f"Rumors: {len(new_town['rumors'])}")
    
    # Test town retrieval from cache
    logger.info("Testing town retrieval from cache...")
    cached_town = await generator.get_or_generate_town("test_town")
    
    assert cached_town['id'] == new_town['id'], "Town IDs don't match"
    assert cached_town['name'] == new_town['name'], "Town names don't match"
    
    logger.info("Town retrieval from cache successful")
    
    # Test building retrieval
    logger.info("Testing building retrieval...")
    if new_town['buildings']:
        building_id = new_town['buildings'][0]['id']
        building = generator.get_building("test_town", building_id)
        
        assert building is not None, "Building not found"
        assert building['id'] == building_id, "Building IDs don't match"
        
        logger.info(f"Retrieved building: {building['name']}")
    else:
        logger.warning("No buildings to test retrieval")
    
    # Test NPC retrieval
    logger.info("Testing NPC retrieval...")
    if new_town['npcs']:
        npc_id = new_town['npcs'][0]['id']
        npc = generator.get_npc("test_town", npc_id)
        
        assert npc is not None, "NPC not found"
        assert npc['id'] == npc_id, "NPC IDs don't match"
        
        logger.info(f"Retrieved NPC: {npc['name']}")
    else:
        logger.warning("No NPCs to test retrieval")
    
    # Test rumor retrieval
    logger.info("Testing rumor retrieval...")
    rumors = generator.get_rumors("test_town")
    
    assert len(rumors) == len(new_town['rumors']), "Rumor counts don't match"
    
    logger.info(f"Retrieved {len(rumors)} rumors")
    
    # Test quest retrieval
    logger.info("Testing quest retrieval...")
    quests = generator.get_quests("test_town")
    
    logger.info(f"Retrieved {len(quests)} quests")
    
    # Save town data to file for inspection
    with open("test_town.json", "w") as f:
        json.dump(new_town, f, indent=2)
    
    logger.info("Town data saved to test_town.json")
    
    return initial_town, new_town

async def test_world_agent_integration(initial_town):
    """Test World Agent integration with town generator"""
    logger.info("Testing World Agent integration...")
    
    # Create World Agent
    world_agent = WorldAgent("TestWorldAgent")
    
    # Initialize World Agent (this should generate the starting town)
    await world_agent.initialize()
    
    assert world_agent.starting_town is not None, "Starting town not generated"
    assert world_agent.starting_town['id'] == initial_town['id'], "Starting town IDs don't match"
    
    logger.info(f"World Agent initialized with starting town: {world_agent.starting_town['name']}")
    
    # Test town generation through World Agent
    logger.info("Testing town generation through World Agent...")
    
    # Create a game state
    game_state = GameState()
    
    # Generate a town
    town_result = await world_agent.process({
        "generation_request": {
            "type": "town",
            "town_id": "test_town"
        },
        "game_state": game_state.to_dict()
    })
    
    assert town_result['success'], "Town generation failed"
    assert 'game_state_changes' in town_result, "No game state changes returned"
    assert 'towns' in town_result['game_state_changes'], "No towns in game state changes"
    assert 'test_town' in town_result['game_state_changes']['towns'], "Test town not in game state changes"
    
    logger.info("Town generation through World Agent successful")
    
    # Test town exploration
    logger.info("Testing town exploration...")
    
    # Update game state with town
    game_state.update(town_result['game_state_changes'])
    
    # Explore the town
    exploration_result = await world_agent.process({
        "generation_request": {
            "type": "town_exploration",
            "town_id": "test_town",
            "action": "look_around"
        },
        "game_state": game_state.to_dict()
    })
    
    assert exploration_result['success'], "Town exploration failed"
    
    logger.info("Town exploration successful")
    logger.info(f"Exploration result: {exploration_result['narrative_summary']}")
    
    # Test building interaction
    logger.info("Testing building interaction...")
    
    # Get a building from the town
    town_data = game_state.towns['test_town']
    if town_data['buildings']:
        building_id = town_data['buildings'][0]['id']
        
        # Interact with the building
        building_result = await world_agent.process({
            "generation_request": {
                "type": "building_interaction",
                "town_id": "test_town",
                "building_id": building_id,
                "action": "look_around"
            },
            "game_state": game_state.to_dict()
        })
        
        assert building_result['success'], "Building interaction failed"
        
        logger.info("Building interaction successful")
        logger.info(f"Building interaction result: {building_result['narrative_summary']}")
    else:
        logger.warning("No buildings to test interaction")
    
    # Test NPC interaction
    logger.info("Testing NPC interaction...")
    
    # Get an NPC from the town
    if town_data['npcs']:
        npc_id = town_data['npcs'][0]['id']
        
        # Interact with the NPC
        npc_result = await world_agent.process({
            "generation_request": {
                "type": "npc_interaction",
                "town_id": "test_town",
                "npc_id": npc_id,
                "action": "talk"
            },
            "game_state": game_state.to_dict()
        })
        
        assert npc_result['success'], "NPC interaction failed"
        
        logger.info("NPC interaction successful")
        logger.info(f"NPC interaction result: {npc_result['narrative_summary']}")
    else:
        logger.warning("No NPCs to test interaction")
    
    return game_state

async def test_game_state_model(game_state, new_town):
    """Test game state model support for town data"""
    logger.info("Testing game state model support for town data...")
    
    # Test town data in game state
    assert 'test_town' in game_state.towns, "Test town not in game state"
    
    # Test town retrieval
    town = game_state.get_town('test_town')
    
    assert town is not None, "Town not retrieved from game state"
    assert town.id == 'test_town', "Town ID doesn't match"
    assert town.name == new_town['name'], "Town name doesn't match"
    
    logger.info(f"Retrieved town from game state: {town.name}")
    
    # Test building retrieval
    if new_town['buildings']:
        building_id = new_town['buildings'][0]['id']
        building = game_state.get_building(building_id, 'test_town')
        
        assert building is not None, "Building not retrieved from game state"
        assert building.id == building_id, "Building ID doesn't match"
        
        logger.info(f"Retrieved building from game state: {building.name}")
    else:
        logger.warning("No buildings to test retrieval from game state")
    
    # Test NPC retrieval
    if new_town['npcs']:
        npc_id = new_town['npcs'][0]['id']
        npc = game_state.get_npc(npc_id)
        
        assert npc is not None, "NPC not retrieved from game state"
        assert npc.id == npc_id, "NPC ID doesn't match"
        
        logger.info(f"Retrieved NPC from game state: {npc.name}")
    else:
        logger.warning("No NPCs to test retrieval from game state")
    
    # Test game state serialization and deserialization
    logger.info("Testing game state serialization and deserialization...")
    
    # Serialize game state
    game_state_dict = game_state.to_dict()
    
    # Deserialize game state
    new_game_state = GameState.from_dict(game_state_dict)
    
    # Verify town data
    assert 'test_town' in new_game_state.towns, "Test town not in deserialized game state"
    
    # Save game state to file for inspection
    with open("test_game_state.json", "w") as f:
        json.dump(game_state_dict, f, indent=2)
    
    logger.info("Game state saved to test_game_state.json")
    
    return new_game_state

async def run_tests():
    """Run all tests"""
    logger.info("Starting town generator integration tests...")
    
    try:
        # Test town generator
        initial_town, new_town = await test_town_generator()
        
        # Test World Agent integration
        game_state = await test_world_agent_integration(initial_town)
        
        # Test game state model
        new_game_state = await test_game_state_model(game_state, new_town)
        
        logger.info("All tests completed successfully!")
        return True
    except Exception as e:
        logger.error(f"Test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = asyncio.run(run_tests())
    sys.exit(0 if success else 1)
