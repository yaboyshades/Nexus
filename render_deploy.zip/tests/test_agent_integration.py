"""
Integration tests for the agent system with Model Protocol Server
"""
import unittest
from unittest.mock import AsyncMock, patch, MagicMock
import sys
import os
import json
import asyncio

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.base_agent import Agent
from agents.intent_agent import IntentAgent
from agents.rule_agent import RuleAgent
from agents.narrative_agent import NarrativeAgent
from agents.world_agent import WorldAgent
from agents.supervisor_agent import SupervisorAgent
from model_protocol_server import get_model_server

class TestAgentIntegration(unittest.TestCase):
    """Test cases for agent integration with Model Protocol Server"""
    
    def setUp(self):
        """Set up test fixtures"""
        # Mock the model server
        self.model_server_mock = MagicMock()
        self.model_server_mock.generate = AsyncMock()
        self.model_server_mock.generate_with_json = AsyncMock()
        
        # Patch the get_model_server function to return our mock
        self.get_model_server_patcher = patch('agents.base_agent.get_model_server', return_value=self.model_server_mock)
        self.get_model_server_mock = self.get_model_server_patcher.start()
        
        # Create test agents
        self.intent_agent = IntentAgent("TestIntentAgent")
        self.rule_agent = RuleAgent("TestRuleAgent")
        self.narrative_agent = NarrativeAgent("TestNarrativeAgent")
        self.world_agent = WorldAgent("TestWorldAgent")
        self.supervisor_agent = SupervisorAgent("TestSupervisorAgent")
        
        # Register agents with supervisor
        self.supervisor_agent.register_agent("intent", self.intent_agent)
        self.supervisor_agent.register_agent("rule", self.rule_agent)
        self.supervisor_agent.register_agent("narrative", self.narrative_agent)
        self.supervisor_agent.register_agent("world", self.world_agent)
        
        # Set up test game state
        self.test_game_state = {
            "player_character": {
                "name": "Test Character",
                "race": "Human",
                "class": "Fighter",
                "level": 1,
                "hp": 10,
                "max_hp": 10,
                "ac": 15,
                "attack_bonus": 3,
                "damage_dice": "1d8",
                "damage_bonus": 2,
                "known_spells": []
            },
            "current_location": {
                "id": "loc_1",
                "name": "Test Room",
                "description": "A simple test room with stone walls.",
                "exits": {
                    "north": "loc_2"
                },
                "npcs": [
                    {
                        "id": "npc_1",
                        "name": "Test NPC",
                        "description": "A test NPC for integration testing."
                    }
                ],
                "monsters": [
                    {
                        "id": "monster_1",
                        "name": "Test Goblin",
                        "hp": 7,
                        "max_hp": 7,
                        "ac": 12,
                        "xp_value": 50
                    }
                ],
                "items": [
                    {
                        "id": "item_1",
                        "name": "Test Potion",
                        "description": "A test healing potion."
                    }
                ]
            },
            "locations": {
                "loc_1": {
                    "id": "loc_1",
                    "name": "Test Room",
                    "description": "A simple test room with stone walls.",
                    "exits": {
                        "north": "loc_2"
                    }
                }
            }
        }
        
        # Set game state in supervisor
        self.supervisor_agent.game_state = self.test_game_state
    
    def tearDown(self):
        """Tear down test fixtures"""
        self.get_model_server_patcher.stop()
    
    async def test_intent_agent_process(self):
        """Test intent agent processing with Model Protocol Server"""
        # Set up mock response
        intent_response = {
            "success": True,
            "confidence": 0.9,
            "parsed_intent": {
                "action": "attack",
                "target_id": "monster_1",
                "target_name": "goblin"
            }
        }
        self.model_server_mock.generate_with_json.return_value = intent_response
        
        # Process input
        input_data = {
            "player_input": "I attack the goblin",
            "game_state": self.test_game_state
        }
        result = await self.intent_agent.process(input_data)
        
        # Verify result
        self.assertEqual(result, intent_response)
        
        # Verify model server was called
        self.model_server_mock.generate_with_json.assert_called_once()
        
        # Verify prompt contains player input
        args, kwargs = self.model_server_mock.generate_with_json.call_args
        self.assertIn("I attack the goblin", args[0])
    
    async def test_rule_agent_process(self):
        """Test rule agent processing with Model Protocol Server"""
        # Set up mock response
        rule_response = {
            "success": True,
            "narrative_summary": "You hit the goblin for 8 damage.",
            "game_state_changes": {
                "current_location": {
                    "monsters": [
                        {
                            "id": "monster_1",
                            "hp": 0
                        }
                    ]
                }
            }
        }
        self.model_server_mock.generate_with_json.return_value = rule_response
        
        # Process input
        input_data = {
            "parsed_intent": {
                "action": "attack",
                "target_id": "monster_1",
                "target_name": "goblin"
            },
            "game_state": self.test_game_state
        }
        result = await self.rule_agent.process(input_data)
        
        # Verify result
        self.assertEqual(result["success"], rule_response["success"])
        self.assertEqual(result["narrative_summary"], rule_response["narrative_summary"])
        
        # Verify model server was called
        self.model_server_mock.generate_with_json.assert_called_once()
    
    async def test_narrative_agent_process(self):
        """Test narrative agent processing with Model Protocol Server"""
        # Set up mock response
        narrative_response = {
            "narrative": "You swing your sword with precision, striking the goblin for 8 damage. The creature falls to the ground, defeated."
        }
        self.model_server_mock.generate_with_json.return_value = narrative_response
        
        # Process input
        input_data = {
            "rule_outcome": {
                "success": True,
                "narrative_summary": "You hit the goblin for 8 damage."
            },
            "parsed_intent": {
                "action": "attack",
                "target_id": "monster_1",
                "target_name": "goblin"
            },
            "player_input": "I attack the goblin",
            "game_state": self.test_game_state
        }
        result = await self.narrative_agent.process(input_data)
        
        # Verify result
        self.assertEqual(result, narrative_response)
        
        # Verify model server was called
        self.model_server_mock.generate_with_json.assert_called_once()
    
    async def test_world_agent_process(self):
        """Test world agent processing with Model Protocol Server"""
        # Set up mock response
        world_response = {
            "success": True,
            "game_state_changes": {
                "locations": {
                    "loc_2": {
                        "id": "loc_2",
                        "name": "Northern Chamber",
                        "description": "A larger chamber with a high ceiling.",
                        "exits": {
                            "south": "loc_1"
                        }
                    }
                }
            },
            "narrative_summary": "You discover a Northern Chamber."
        }
        self.model_server_mock.generate_with_json.return_value = world_response
        
        # Process input
        input_data = {
            "generation_request": {
                "type": "location",
                "location_id": "loc_2",
                "direction_from": "loc_1",
                "direction": "north"
            },
            "game_state": self.test_game_state
        }
        result = await self.world_agent.process(input_data)
        
        # Verify result
        self.assertEqual(result["success"], world_response["success"])
        self.assertEqual(result["narrative_summary"], world_response["narrative_summary"])
        
        # Verify model server was called
        self.model_server_mock.generate_with_json.assert_called_once()
    
    async def test_supervisor_agent_process(self):
        """Test supervisor agent processing with Model Protocol Server"""
        # Set up mock responses for each agent
        intent_response = {
            "success": True,
            "confidence": 0.9,
            "parsed_intent": {
                "action": "attack",
                "target_id": "monster_1",
                "target_name": "goblin"
            }
        }
        
        rule_response = {
            "success": True,
            "narrative_summary": "You hit the goblin for 8 damage.",
            "game_state_changes": {
                "current_location": {
                    "monsters": [
                        {
                            "id": "monster_1",
                            "hp": 0
                        }
                    ]
                }
            }
        }
        
        narrative_response = {
            "narrative": "You swing your sword with precision, striking the goblin for 8 damage. The creature falls to the ground, defeated."
        }
        
        # Mock the agent process methods
        self.intent_agent.process = AsyncMock(return_value=intent_response)
        self.rule_agent.process = AsyncMock(return_value=rule_response)
        self.narrative_agent.process = AsyncMock(return_value=narrative_response)
        
        # Process input
        input_data = {
            "player_input": "I attack the goblin",
            "user_id": "test_user",
            "game_state": self.test_game_state
        }
        result = await self.supervisor_agent.process(input_data)
        
        # Verify result
        self.assertEqual(result["response_type"], "narrative")
        self.assertEqual(result["message"], narrative_response["narrative"])
        
        # Verify agents were called
        self.intent_agent.process.assert_called_once()
        self.rule_agent.process.assert_called_once()
        self.narrative_agent.process.assert_called_once()
    
    async def test_end_to_end_flow(self):
        """Test end-to-end flow with all agents"""
        # Set up mock responses for the model server
        self.model_server_mock.generate_with_json.side_effect = [
            # Intent agent response
            {
                "success": True,
                "confidence": 0.9,
                "parsed_intent": {
                    "action": "attack",
                    "target_id": "monster_1",
                    "target_name": "goblin"
                }
            },
            # Rule agent response
            {
                "success": True,
                "narrative_summary": "You hit the goblin for 8 damage.",
                "game_state_changes": {
                    "current_location": {
                        "monsters": [
                            {
                                "id": "monster_1",
                                "hp": 0
                            }
                        ]
                    }
                }
            },
            # Narrative agent response
            {
                "narrative": "You swing your sword with precision, striking the goblin for 8 damage. The creature falls to the ground, defeated."
            }
        ]
        
        # Process input through supervisor
        input_data = {
            "player_input": "I attack the goblin",
            "user_id": "test_user",
            "game_state": self.test_game_state
        }
        result = await self.supervisor_agent.process(input_data)
        
        # Verify result
        self.assertEqual(result["response_type"], "narrative")
        self.assertIn("swing your sword", result["message"])
        self.assertIn("goblin", result["message"])
        
        # Verify model server was called multiple times
        self.assertEqual(self.model_server_mock.generate_with_json.call_count, 3)
        
        # Verify game state was updated
        monster = next((m for m in self.supervisor_agent.game_state["current_location"]["monsters"] if m["id"] == "monster_1"), None)
        self.assertIsNotNone(monster)
        self.assertEqual(monster["hp"], 0)

if __name__ == '__main__':
    unittest.main()
