"""
Chronicle Weave - Data Models
"""
