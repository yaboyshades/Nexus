"""
Game Models with Town Data Support for Digital DM Game

This module defines the data models used in the game, including
enhanced support for town data structures from the town generator.
"""

from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass, field
import json
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('models.game_models')

@dataclass
class PlayerCharacter:
    """Player character data model"""
    id: str = "player"
    name: str = "Adventurer"
    race: str = "Human"
    class_name: str = "Fighter"  # Changed from character_class to match game_server.py
    level: int = 1
    hp: int = 10
    max_hp: int = 10
    ac: int = 15
    attack_bonus: int = 3
    damage_dice: str = "1d8"
    damage_bonus: int = 2
    inventory: List[str] = field(default_factory=lambda: ["sword", "shield", "backpack"])
    known_spells: List[Dict[str, Any]] = field(default_factory=list)
    spell_slots: Dict[str, int] = field(default_factory=dict)
    gold: int = 50
    experience: int = 0
    strength: int = 10
    dexterity: int = 10
    constitution: int = 10
    intelligence: int = 10
    wisdom: int = 10
    charisma: int = 10
    current_location_id: str = "town_square"
    active_combat_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "race": self.race,
            "class_name": self.class_name,
            "level": self.level,
            "hp": self.hp,
            "max_hp": self.max_hp,
            "ac": self.ac,
            "attack_bonus": self.attack_bonus,
            "damage_dice": self.damage_dice,
            "damage_bonus": self.damage_bonus,
            "inventory": self.inventory,
            "known_spells": self.known_spells,
            "spell_slots": self.spell_slots,
            "gold": self.gold,
            "experience": self.experience,
            "strength": self.strength,
            "dexterity": self.dexterity,
            "constitution": self.constitution,
            "intelligence": self.intelligence,
            "wisdom": self.wisdom,
            "charisma": self.charisma,
            "current_location_id": self.current_location_id,
            "active_combat_id": self.active_combat_id
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PlayerCharacter':
        """Create from dictionary"""
        return cls(
            id=data.get("id", "player"),
            name=data.get("name", "Adventurer"),
            race=data.get("race", "Human"),
            class_name=data.get("class_name", "Fighter"),
            level=data.get("level", 1),
            hp=data.get("hp", 10),
            max_hp=data.get("max_hp", 10),
            ac=data.get("ac", 15),
            attack_bonus=data.get("attack_bonus", 3),
            damage_dice=data.get("damage_dice", "1d8"),
            damage_bonus=data.get("damage_bonus", 2),
            inventory=data.get("inventory", ["sword", "shield", "backpack"]),
            known_spells=data.get("known_spells", []),
            spell_slots=data.get("spell_slots", {}),
            gold=data.get("gold", 50),
            experience=data.get("experience", 0),
            strength=data.get("strength", 10),
            dexterity=data.get("dexterity", 10),
            constitution=data.get("constitution", 10),
            intelligence=data.get("intelligence", 10),
            wisdom=data.get("wisdom", 10),
            charisma=data.get("charisma", 10),
            current_location_id=data.get("current_location_id", "town_square"),
            active_combat_id=data.get("active_combat_id")
        )

@dataclass
class Combat:
    """Combat data model - Added to fix import error"""
    id: str
    location_id: str
    round: int = 1
    current_turn: str = "player"
    initiative_order: List[Dict[str, Any]] = field(default_factory=list)
    enemies: List[Dict[str, Any]] = field(default_factory=list)
    log: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "location_id": self.location_id,
            "round": self.round,
            "current_turn": self.current_turn,
            "initiative_order": self.initiative_order,
            "enemies": self.enemies,
            "log": self.log
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Combat':
        """Create from dictionary"""
        return cls(
            id=data["id"],
            location_id=data["location_id"],
            round=data.get("round", 1),
            current_turn=data.get("current_turn", "player"),
            initiative_order=data.get("initiative_order", []),
            enemies=data.get("enemies", []),
            log=data.get("log", [])
        )

@dataclass
class NPC:
    """NPC data model"""
    id: str
    name: str
    role: str = "commoner"
    trait: str = "friendly"
    description: str = ""
    building_id: Optional[str] = None
    quests: List[Dict[str, Any]] = field(default_factory=list)
    dialogue: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "role": self.role,
            "trait": self.trait,
            "description": self.description,
            "building_id": self.building_id,
            "quests": self.quests,
            "dialogue": self.dialogue
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NPC':
        """Create from dictionary"""
        return cls(
            id=data["id"],
            name=data["name"],
            role=data.get("role", "commoner"),
            trait=data.get("trait", "friendly"),
            description=data.get("description", ""),
            building_id=data.get("building_id"),
            quests=data.get("quests", []),
            dialogue=data.get("dialogue", [])
        )

@dataclass
class Building:
    """Building data model"""
    id: str
    name: str
    type: str
    description: str = ""
    npcs: List[str] = field(default_factory=list)
    items: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type,
            "description": self.description,
            "npcs": self.npcs,
            "items": self.items
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Building':
        """Create from dictionary"""
        return cls(
            id=data["id"],
            name=data["name"],
            type=data["type"],
            description=data.get("description", ""),
            npcs=data.get("npcs", []),
            items=data.get("items", [])
        )

@dataclass
class Rumor:
    """Rumor data model"""
    id: str
    text: str
    truth: bool = True
    known_by: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "text": self.text,
            "truth": self.truth,
            "known_by": self.known_by
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Rumor':
        """Create from dictionary"""
        return cls(
            id=data["id"],
            text=data["text"],
            truth=data.get("truth", True),
            known_by=data.get("known_by", [])
        )

@dataclass
class Quest:
    """Quest data model"""
    id: str
    description: str
    npc_id: str
    npc_name: str
    town_id: str
    reward: int = 0
    completed: bool = False
    type: str = "fetch"
    target: str = "item"
    difficulty: str = "easy"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "description": self.description,
            "npc_id": self.npc_id,
            "npc_name": self.npc_name,
            "town_id": self.town_id,
            "reward": self.reward,
            "completed": self.completed,
            "type": self.type,
            "target": self.target,
            "difficulty": self.difficulty
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Quest':
        """Create from dictionary"""
        return cls(
            id=data["id"],
            description=data["description"],
            npc_id=data["npc_id"],
            npc_name=data["npc_name"],
            town_id=data["town_id"],
            reward=data.get("reward", 0),
            completed=data.get("completed", False),
            type=data.get("type", "fetch"),
            target=data.get("target", "item"),
            difficulty=data.get("difficulty", "easy")
        )

@dataclass
class Town:
    """Town data model"""
    id: str
    name: str
    size: str
    population: int
    description: str
    buildings: List[Building] = field(default_factory=list)
    npcs: List[NPC] = field(default_factory=list)
    rumors: List[Rumor] = field(default_factory=list)
    meta: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "size": self.size,
            "population": self.population,
            "description": self.description,
            "buildings": [b.to_dict() for b in self.buildings],
            "npcs": [n.to_dict() for n in self.npcs],
            "rumors": [r.to_dict() for r in self.rumors],
            "_meta": self.meta
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Town':
        """Create from dictionary"""
        buildings = []
        for b_data in data.get("buildings", []):
            if isinstance(b_data, dict):
                buildings.append(Building.from_dict(b_data))
            else:
                logger.warning(f"Invalid building data: {b_data}")
        
        npcs = []
        for n_data in data.get("npcs", []):
            if isinstance(n_data, dict):
                npcs.append(NPC.from_dict(n_data))
            else:
                logger.warning(f"Invalid NPC data: {n_data}")
        
        rumors = []
        for r_data in data.get("rumors", []):
            if isinstance(r_data, dict):
                rumors.append(Rumor.from_dict(r_data))
            else:
                logger.warning(f"Invalid rumor data: {r_data}")
        
        return cls(
            id=data["id"],
            name=data["name"],
            size=data["size"],
            population=data["population"],
            description=data["description"],
            buildings=buildings,
            npcs=npcs,
            rumors=rumors,
            meta=data.get("_meta", {})
        )
    
    def get_building(self, building_id: str) -> Optional[Building]:
        """Get a building by ID"""
        for building in self.buildings:
            if building.id == building_id:
                return building
        return None
    
    def get_npc(self, npc_id: str) -> Optional[NPC]:
        """Get an NPC by ID"""
        for npc in self.npcs:
            if npc.id == npc_id:
                return npc
        return None
    
    def get_npcs_in_building(self, building_id: str) -> List[NPC]:
        """Get all NPCs in a building"""
        return [npc for npc in self.npcs if npc.building_id == building_id]
    
    def get_quests(self) -> List[Dict[str, Any]]:
        """Get all quests in the town"""
        quests = []
        for npc in self.npcs:
            for quest in npc.quests:
                quest_copy = quest.copy()
                quest_copy["npc_id"] = npc.id
                quest_copy["npc_name"] = npc.name
                quests.append(quest_copy)
        return quests

@dataclass
class Location:
    """Location data model"""
    id: str
    name: str
    description: str
    exits: Dict[str, str] = field(default_factory=dict)
    npcs: List[str] = field(default_factory=list)
    monsters: List[Dict[str, Any]] = field(default_factory=list)
    items: List[str] = field(default_factory=list)
    is_town: bool = False
    town_id: Optional[str] = None
    is_building: bool = False
    building_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        result = {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "exits": self.exits,
            "npcs": self.npcs,
            "monsters": self.monsters,
            "items": self.items
        }
        
        if self.is_town:
            result["is_town"] = True
            result["town_id"] = self.town_id
        
        if self.is_building:
            result["is_building"] = True
            result["building_id"] = self.building_id
        
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Location':
        """Create from dictionary"""
        return cls(
            id=data["id"],
            name=data["name"],
            description=data["description"],
            exits=data.get("exits", {}),
            npcs=data.get("npcs", []),
            monsters=data.get("monsters", []),
            items=data.get("items", []),
            is_town=data.get("is_town", False),
            town_id=data.get("town_id"),
            is_building=data.get("is_building", False),
            building_id=data.get("building_id")
        )

@dataclass
class GameState:
    """Game state data model"""
    player_characters: Dict[str, PlayerCharacter] = field(default_factory=dict)
    locations: Dict[str, Location] = field(default_factory=dict)
    towns: Dict[str, Town] = field(default_factory=dict)
    active_combats: Dict[str, Combat] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "player_characters": {pc_id: pc.to_dict() for pc_id, pc in self.player_characters.items()},
            "locations": {loc_id: loc.to_dict() for loc_id, loc in self.locations.items()},
            "towns": {town_id: town.to_dict() for town_id, town in self.towns.items()},
            "active_combats": {combat_id: combat.to_dict() for combat_id, combat in self.active_combats.items()}
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'GameState':
        """Create from dictionary"""
        player_characters = {}
        for pc_id, pc_data in data.get("player_characters", {}).items():
            player_characters[pc_id] = PlayerCharacter.from_dict(pc_data)
        
        locations = {}
        for loc_id, loc_data in data.get("locations", {}).items():
            locations[loc_id] = Location.from_dict(loc_data)
        
        towns = {}
        for town_id, town_data in data.get("towns", {}).items():
            towns[town_id] = Town.from_dict(town_data)
        
        active_combats = {}
        for combat_id, combat_data in data.get("active_combats", {}).items():
            active_combats[combat_id] = Combat.from_dict(combat_data)
        
        return cls(
            player_characters=player_characters,
            locations=locations,
            towns=towns,
            active_combats=active_combats
        )
    
    def update(self, changes: Dict[str, Any]) -> None:
        """
        Update game state with changes.
        
        Args:
            changes: Dictionary of changes to apply
        """
        # Update player characters
        if "player_characters" in changes:
            for pc_id, pc_changes in changes["player_characters"].items():
                if pc_id in self.player_characters:
                    pc_dict = self.player_characters[pc_id].to_dict()
                    self._deep_update(pc_dict, pc_changes)
                    self.player_characters[pc_id] = PlayerCharacter.from_dict(pc_dict)
                else:
                    self.player_characters[pc_id] = PlayerCharacter.from_dict(pc_changes)
        
        # Update locations
        if "locations" in changes:
            for loc_id, loc_changes in changes["locations"].items():
                if loc_id in self.locations:
                    loc_dict = self.locations[loc_id].to_dict()
                    self._deep_update(loc_dict, loc_changes)
                    self.locations[loc_id] = Location.from_dict(loc_dict)
                else:
                    self.locations[loc_id] = Location.from_dict(loc_changes)
        
        # Update towns
        if "towns" in changes:
            for town_id, town_changes in changes["towns"].items():
                if town_id in self.towns:
                    town_dict = self.towns[town_id].to_dict()
                    self._deep_update(town_dict, town_changes)
                    self.towns[town_id] = Town.from_dict(town_dict)
                else:
                    self.towns[town_id] = Town.from_dict(town_changes)
        
        # Update active combats
        if "active_combats" in changes:
            for combat_id, combat_changes in changes["active_combats"].items():
                if combat_id in self.active_combats:
                    combat_dict = self.active_combats[combat_id].to_dict()
                    self._deep_update(combat_dict, combat_changes)
                    self.active_combats[combat_id] = Combat.from_dict(combat_dict)
                else:
                    self.active_combats[combat_id] = Combat.from_dict(combat_changes)
    
    def _deep_update(self, target: Dict[str, Any], source: Dict[str, Any]) -> None:
        """
        Recursively update a dictionary.
        
        Args:
            target: Target dictionary to update
            source: Source dictionary with changes
        """
        for key, value in source.items():
            if isinstance(value, dict) and key in target and isinstance(target[key], dict):
                self._deep_update(target[key], value)
            else:
                target[key] = value
    
    def _update_list_by_id(self, target_list: List[Dict[str, Any]], source_list: List[Dict[str, Any]]) -> None:
        """
        Update a list of dictionaries by ID.
        
        Args:
            target_list: Target list to update
            source_list: Source list with changes
        """
        for source_item in source_list:
            if "id" not in source_item:
                continue
            
            # Find matching item in target list
            found = False
            for i, target_item in enumerate(target_list):
                if target_item.get("id") == source_item["id"]:
                    # Update existing item
                    self._deep_update(target_list[i], source_item)
                    found = True
                    break
            
            if not found:
                # Add new item
                target_list.append(source_item)
    
    def get_player_character(self, user_id: str) -> Optional[PlayerCharacter]:
        """Get a player character by user ID"""
        return self.player_characters.get(user_id)
    
    def get_location(self, location_id: str) -> Optional[Location]:
        """Get a location by ID"""
        return self.locations.get(location_id)
    
    def get_town(self, town_id: str) -> Optional[Town]:
        """Get a town by ID"""
        return self.towns.get(town_id)
    
    def get_building(self, building_id: str, town_id: Optional[str] = None) -> Optional[Building]:
        """Get a building by ID"""
        if town_id:
            town = self.get_town(town_id)
            if town:
                return town.get_building(building_id)
        else:
            for town in self.towns.values():
                building = town.get_building(building_id)
                if building:
                    return building
        return None
    
    def get_npc(self, npc_id: str) -> Optional[NPC]:
        """Get an NPC by ID"""
        for town in self.towns.values():
            npc = town.get_npc(npc_id)
            if npc:
                return npc
        return None
    
    def initialize_default_game_state(self) -> None:
        """Initialize default game state"""
        # Create default town square location
        town_square = Location(
            id="town_square",
            name="Town Square",
            description="You stand in the center of a bustling town square. Merchants hawk their wares, and townsfolk go about their daily business. The town seems peaceful, but rumors of trouble in the nearby forest have been circulating.",
            exits={
                "north": "tavern",
                "east": "market",
                "south": "town_gate",
                "west": "blacksmith"
            }
        )
        self.locations["town_square"] = town_square
