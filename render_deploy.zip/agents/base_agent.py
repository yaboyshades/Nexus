"""
Base Agent with Model Protocol Server integration
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import logging
import asyncio

from model_protocol_server import get_model_server

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

class Agent(ABC):
    """
    Base agent class that all specialized agents inherit from.
    Provides common functionality and defines the agent interface.
    """
    
    def __init__(self, name: str, model_backend: str = None):
        """
        Initialize the agent.
        
        Args:
            name: Agent name
            model_backend: Name of the model backend to use (defaults to server default)
        """
        self.name = name
        self.model_backend = model_backend
        self.logger = logging.getLogger(f'agent.{name}')
        self.model_server = get_model_server()
        self.logger.info(f"Agent {name} initialized with model backend: {model_backend or 'default'}")
    
    @abstractmethod
    async def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process input data and return results.
        
        Args:
            input_data: Input data dictionary
            
        Returns:
            Processing results
        """
        pass
    
    async def generate_text(self, prompt: str, params: Optional[Dict[str, Any]] = None) -> str:
        """
        Generate text using the model protocol server.
        
        Args:
            prompt: Input prompt
            params: Generation parameters
            
        Returns:
            Generated text
        """
        params = params or {}
        self.logger.debug(f"Generating text with prompt: {prompt[:50]}...")
        
        try:
            return await self.model_server.generate(
                prompt=prompt,
                params=params,
                backend_name=self.model_backend
            )
        except Exception as e:
            self.logger.error(f"Error generating text: {str(e)}")
            return f"Error generating response: {str(e)}"
    
    async def generate_json(self, 
                          prompt: str, 
                          json_schema: Dict[str, Any],
                          params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Generate JSON using the model protocol server.
        
        Args:
            prompt: Input prompt
            json_schema: JSON schema for the expected response
            params: Generation parameters
            
        Returns:
            Generated JSON
        """
        params = params or {}
        self.logger.debug(f"Generating JSON with prompt: {prompt[:50]}...")
        
        try:
            return await self.model_server.generate_with_json(
                prompt=prompt,
                json_schema=json_schema,
                params=params,
                backend_name=self.model_backend
            )
        except Exception as e:
            self.logger.error(f"Error generating JSON: {str(e)}")
            return {"error": str(e)}
