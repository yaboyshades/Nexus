"""
World Agent with Town Generator Integration for Digital DM Game

This module extends the World Agent to use the town generator for
creating and managing towns, locations, NPCs, and quests.
"""

from typing import Dict, Any, List, Optional, Union
import logging
import json
import asyncio
import random
from pathlib import Path

from .base_agent import Agent
from model_protocol_server import get_model_server
import town_generator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('agent.WorldAgent')

class WorldAgent(Agent):
    """
    Agent responsible for world generation, including locations,
    NPCs, items, and environmental descriptions. Now integrated
    with the town generator for rich town environments.
    """
    
    def __init__(self, name: str, model_backend: str = "default"):
        """
        Initialize the World Agent.
        
        Args:
            name: Name of the agent
            model_backend: Model backend to use
        """
        super().__init__(name, model_backend)
        logger.info(f"World Agent {name} initialized")
        
        # Initialize town generator
        self.town_generator = town_generator.get_town_generator()
        
        # Track generated locations
        self.generated_locations = set()
        
        # Initialize starting town
        self.starting_town = None
    
    async def initialize(self) -> None:
        """Initialize the agent, including generating the starting town."""
        logger.info("Initializing World Agent with starting town...")
        self.starting_town = await town_generator.generate_initial_town()
        logger.info(f"Starting town '{self.starting_town['name']}' generated successfully.")
    
    async def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process input data and generate world content.
        
        Args:
            input_data: Input data containing generation request and game state
            
        Returns:
            Dict containing generated content and game state changes
        """
        generation_request = input_data.get("generation_request", {})
        game_state = input_data.get("game_state", {})
        
        generation_type = generation_request.get("type", "")
        
        if generation_type == "location":
            return await self._generate_location(generation_request, game_state)
        elif generation_type == "npc":
            return await self._generate_npc(generation_request, game_state)
        elif generation_type == "item":
            return await self._generate_item(generation_request, game_state)
        elif generation_type == "dialogue":
            return await self._generate_dialogue(generation_request, game_state)
        elif generation_type == "town":
            return await self._generate_town(generation_request, game_state)
        elif generation_type == "town_exploration":
            return await self._handle_town_exploration(generation_request, game_state)
        elif generation_type == "building_interaction":
            return await self._handle_building_interaction(generation_request, game_state)
        elif generation_type == "npc_interaction":
            return await self._handle_npc_interaction(generation_request, game_state)
        else:
            logger.warning(f"Unknown generation type: {generation_type}")
            return {
                "success": False,
                "error": f"Unknown generation type: {generation_type}",
                "narrative_summary": "The world around you remains unchanged."
            }
    
    async def _generate_location(self, request: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a new location or retrieve an existing one.
        
        Args:
            request: Generation request details
            game_state: Current game state
            
        Returns:
            Dict containing the generated location and game state changes
        """
        location_id = request.get("location_id", "")
        direction_from = request.get("direction_from", "")
        direction = request.get("direction", "")
        
        # Check if this is a town location
        if location_id.startswith("town_"):
            town_id = location_id.split("_")[1]
            return await self._generate_town({"town_id": town_id}, game_state)
        
        # Check if location already exists in game state
        if location_id in game_state.get("locations", {}):
            logger.info(f"Location {location_id} already exists, retrieving from game state.")
            location = game_state["locations"][location_id]
            
            return {
                "success": True,
                "game_state_changes": {},
                "narrative_summary": f"You are in {location['name']}. {location['description']}"
            }
        
        # Generate new location using the model
        logger.info(f"Generating new location {location_id}...")
        
        # Prepare context for the model
        context = {
            "location_id": location_id,
            "direction_from": direction_from,
            "direction": direction,
            "existing_locations": list(game_state.get("locations", {}).values())
        }
        
        # Generate location with the model
        model_server = get_model_server()
        location_data = await model_server.generate_with_json(
            f"Generate a new location with ID {location_id} that is {direction} of {direction_from}. "
            f"Create a name, description, and possible exits. Make it interesting and detailed.",
            context
        )
        
        # Ensure the location has all required fields
        if not location_data.get("name") or not location_data.get("description"):
            logger.warning(f"Generated location {location_id} is missing required fields.")
            # Create fallback location
            location_data = {
                "id": location_id,
                "name": f"Area {location_id}",
                "description": "A nondescript area with little of interest.",
                "exits": {}
            }
            
            # Add reciprocal exit
            if direction_from and direction:
                opposite_directions = {
                    "north": "south",
                    "south": "north",
                    "east": "west",
                    "west": "east",
                    "up": "down",
                    "down": "up"
                }
                if direction in opposite_directions:
                    location_data["exits"][opposite_directions[direction]] = direction_from
        
        # Track this location as generated
        self.generated_locations.add(location_id)
        
        # Prepare game state changes
        game_state_changes = {
            "locations": {
                location_id: location_data
            }
        }
        
        # If this is a new location, update the exit in the source location
        if direction_from and direction and direction_from in game_state.get("locations", {}):
            if "locations" not in game_state_changes:
                game_state_changes["locations"] = {}
            
            if direction_from not in game_state_changes["locations"]:
                game_state_changes["locations"][direction_from] = {
                    "id": direction_from,
                    "exits": {}
                }
            
            if "exits" not in game_state_changes["locations"][direction_from]:
                game_state_changes["locations"][direction_from]["exits"] = {}
            
            game_state_changes["locations"][direction_from]["exits"][direction] = location_id
        
        return {
            "success": True,
            "game_state_changes": game_state_changes,
            "narrative_summary": f"You discover {location_data['name']}. {location_data['description']}"
        }
    
    async def _generate_town(self, request: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a town or retrieve an existing one.
        
        Args:
            request: Generation request details
            game_state: Current game state
            
        Returns:
            Dict containing the generated town and game state changes
        """
        town_id = request.get("town_id", "")
        
        # If no town ID specified, use the starting town
        if not town_id:
            if not self.starting_town:
                # Initialize starting town if not done yet
                await self.initialize()
            town_id = self.starting_town["id"]
        
        # Check if this town already exists in game state
        town_location_id = f"town_{town_id}"
        if town_location_id in game_state.get("locations", {}):
            logger.info(f"Town {town_id} already exists in game state, retrieving.")
            town_location = game_state["locations"][town_location_id]
            
            return {
                "success": True,
                "game_state_changes": {},
                "narrative_summary": f"You are in {town_location['name']}. {town_location['description']}"
            }
        
        # Generate or retrieve town from town generator
        logger.info(f"Generating or retrieving town {town_id}...")
        town_data = await self.town_generator.get_or_generate_town(town_id)
        
        # Create a location entry for the town
        town_location = {
            "id": town_location_id,
            "name": town_data["name"],
            "description": town_data["description"],
            "is_town": True,
            "town_id": town_id,
            "exits": {},
            "buildings": [b["id"] for b in town_data["buildings"]],
            "npcs": [n["id"] for n in town_data["npcs"] if not n.get("building_id")]  # NPCs in the town square
        }
        
        # Create location entries for each building
        building_locations = {}
        for building in town_data["buildings"]:
            building_location_id = f"building_{town_id}_{building['id']}"
            building_locations[building_location_id] = {
                "id": building_location_id,
                "name": building["name"],
                "description": building["description"],
                "is_building": True,
                "building_id": building["id"],
                "town_id": town_id,
                "exits": {
                    "out": town_location_id  # Exit to town
                },
                "npcs": building.get("npcs", [])
            }
            
            # Add building as an exit from town
            town_location["exits"][building["name"]] = building_location_id
        
        # Prepare game state changes
        game_state_changes = {
            "locations": {
                town_location_id: town_location
            },
            "towns": {
                town_id: town_data
            }
        }
        
        # Add building locations to game state changes
        for location_id, location in building_locations.items():
            game_state_changes["locations"][location_id] = location
        
        return {
            "success": True,
            "game_state_changes": game_state_changes,
            "narrative_summary": f"You arrive at {town_data['name']}, {town_data['size']}. {town_data['description']}"
        }
    
    async def _handle_town_exploration(self, request: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle exploration within a town.
        
        Args:
            request: Exploration request details
            game_state: Current game state
            
        Returns:
            Dict containing exploration results and game state changes
        """
        town_id = request.get("town_id", "")
        action = request.get("action", "")
        
        if not town_id:
            return {
                "success": False,
                "error": "No town ID specified for exploration",
                "narrative_summary": "You're not sure which direction to explore."
            }
        
        # Get town data
        town_data = None
        if town_id in game_state.get("towns", {}):
            town_data = game_state["towns"][town_id]
        else:
            town_data = await self.town_generator.get_or_generate_town(town_id)
        
        if not town_data:
            return {
                "success": False,
                "error": f"Town {town_id} not found",
                "narrative_summary": "You can't seem to find that place."
            }
        
        # Handle different exploration actions
        if action == "look_around":
            # Generate a description of the town square
            buildings_desc = ", ".join([b["name"] for b in town_data["buildings"][:5]])
            if len(town_data["buildings"]) > 5:
                buildings_desc += f", and {len(town_data['buildings']) - 5} other buildings"
            
            npcs_in_square = [n for n in town_data["npcs"] if not n.get("building_id")]
            npcs_desc = ""
            if npcs_in_square:
                npc_names = [n["name"] for n in npcs_in_square[:3]]
                if len(npcs_in_square) > 3:
                    npcs_desc = f"You see {', '.join(npc_names)}, and {len(npcs_in_square) - 3} other people in the town square."
                else:
                    npcs_desc = f"You see {', '.join(npc_names)} in the town square."
            
            narrative = f"You look around {town_data['name']}. {town_data['description']}\n\n"
            narrative += f"The town has {buildings_desc}.\n\n"
            if npcs_desc:
                narrative += npcs_desc
            
            return {
                "success": True,
                "game_state_changes": {},
                "narrative_summary": narrative
            }
        
        elif action == "ask_about_rumors":
            # Get rumors from the town
            rumors = town_data.get("rumors", [])
            if not rumors:
                return {
                    "success": True,
                    "game_state_changes": {},
                    "narrative_summary": "You ask around, but nobody seems to have any interesting rumors to share."
                }
            
            # Select a random rumor
            rumor = random.choice(rumors)
            
            # Find an NPC who knows this rumor
            npc = None
            if "known_by" in rumor and rumor["known_by"]:
                npc_id = random.choice(rumor["known_by"])
                for n in town_data["npcs"]:
                    if n["id"] == npc_id:
                        npc = n
                        break
            
            if npc:
                narrative = f"{npc['name']} tells you: \"{rumor['text']}\""
            else:
                narrative = f"You hear a rumor: {rumor['text']}"
            
            return {
                "success": True,
                "game_state_changes": {},
                "narrative_summary": narrative
            }
        
        elif action == "find_quests":
            # Get quests from the town
            quests = []
            for npc in town_data["npcs"]:
                for quest in npc.get("quests", []):
                    if not quest.get("completed", False):
                        quests.append({
                            "quest": quest,
                            "npc": npc
                        })
            
            if not quests:
                return {
                    "success": True,
                    "game_state_changes": {},
                    "narrative_summary": "You ask around, but nobody seems to have any tasks they need help with."
                }
            
            # Select a random quest
            quest_info = random.choice(quests)
            quest = quest_info["quest"]
            npc = quest_info["npc"]
            
            narrative = f"{npc['name']}, the {npc['role']}, has a quest for you: {quest['description']}\n\n"
            narrative += f"Reward: {quest['reward']} gold coins."
            
            # Add quest to game state if not already there
            game_state_changes = {}
            if "quests" not in game_state:
                game_state_changes["quests"] = []
            
            if quest["id"] not in [q["id"] for q in game_state.get("quests", [])]:
                game_state_changes["quests"] = game_state.get("quests", []) + [{
                    "id": quest["id"],
                    "description": quest["description"],
                    "npc_id": npc["id"],
                    "npc_name": npc["name"],
                    "town_id": town_id,
                    "reward": quest["reward"],
                    "completed": False
                }]
            
            return {
                "success": True,
                "game_state_changes": game_state_changes,
                "narrative_summary": narrative
            }
        
        else:
            return {
                "success": False,
                "error": f"Unknown town exploration action: {action}",
                "narrative_summary": "You're not sure how to do that in this town."
            }
    
    async def _handle_building_interaction(self, request: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle interaction with a building in a town.
        
        Args:
            request: Interaction request details
            game_state: Current game state
            
        Returns:
            Dict containing interaction results and game state changes
        """
        town_id = request.get("town_id", "")
        building_id = request.get("building_id", "")
        action = request.get("action", "")
        
        if not town_id or not building_id:
            return {
                "success": False,
                "error": "Town ID or building ID not specified",
                "narrative_summary": "You're not sure which building to interact with."
            }
        
        # Get town data
        town_data = None
        if town_id in game_state.get("towns", {}):
            town_data = game_state["towns"][town_id]
        else:
            town_data = await self.town_generator.get_or_generate_town(town_id)
        
        if not town_data:
            return {
                "success": False,
                "error": f"Town {town_id} not found",
                "narrative_summary": "You can't seem to find that place."
            }
        
        # Find the building
        building = None
        for b in town_data["buildings"]:
            if b["id"] == building_id:
                building = b
                break
        
        if not building:
            return {
                "success": False,
                "error": f"Building {building_id} not found in town {town_id}",
                "narrative_summary": "You can't seem to find that building."
            }
        
        # Handle different building interactions
        if action == "enter":
            # Get NPCs in the building
            npcs_in_building = []
            for npc in town_data["npcs"]:
                if npc.get("building_id") == building_id:
                    npcs_in_building.append(npc)
            
            npcs_desc = ""
            if npcs_in_building:
                npc_names = [n["name"] for n in npcs_in_building[:3]]
                if len(npcs_in_building) > 3:
                    npcs_desc = f"Inside, you see {', '.join(npc_names)}, and {len(npcs_in_building) - 3} other people."
                else:
                    npcs_desc = f"Inside, you see {', '.join(npc_names)}."
            
            narrative = f"You enter {building['name']}, {building['type']}. {building['description']}\n\n"
            if npcs_desc:
                narrative += npcs_desc
            
            # Update current location in game state
            building_location_id = f"building_{town_id}_{building_id}"
            game_state_changes = {
                "current_location": {
                    "id": building_location_id
                }
            }
            
            return {
                "success": True,
                "game_state_changes": game_state_changes,
                "narrative_summary": narrative
            }
        
        elif action == "look_around":
            # Generate a description of the building interior
            narrative = f"You look around {building['name']}. {building['description']}\n\n"
            
            # Get NPCs in the building
            npcs_in_building = []
            for npc in town_data["npcs"]:
                if npc.get("building_id") == building_id:
                    npcs_in_building.append(npc)
            
            if npcs_in_building:
                narrative += "You see:\n"
                for npc in npcs_in_building:
                    narrative += f"- {npc['name']}, {npc['description']}\n"
            else:
                narrative += "There doesn't seem to be anyone here at the moment."
            
            return {
                "success": True,
                "game_state_changes": {},
                "narrative_summary": narrative
            }
        
        else:
            return {
                "success": False,
                "error": f"Unknown building interaction action: {action}",
                "narrative_summary": "You're not sure how to do that in this building."
            }
    
    async def _handle_npc_interaction(self, request: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle interaction with an NPC in a town.
        
        Args:
            request: Interaction request details
            game_state: Current game state
            
        Returns:
            Dict containing interaction results and game state changes
        """
        town_id = request.get("town_id", "")
        npc_id = request.get("npc_id", "")
        action = request.get("action", "")
        
        if not town_id or not npc_id:
            return {
                "success": False,
                "error": "Town ID or NPC ID not specified",
                "narrative_summary": "You're not sure who to talk to."
            }
        
        # Get town data
        town_data = None
        if town_id in game_state.get("towns", {}):
            town_data = game_state["towns"][town_id]
        else:
            town_data = await self.town_generator.get_or_generate_town(town_id)
        
        if not town_data:
            return {
                "success": False,
                "error": f"Town {town_id} not found",
                "narrative_summary": "You can't seem to find that place."
            }
        
        # Find the NPC
        npc = None
        for n in town_data["npcs"]:
            if n["id"] == npc_id:
                npc = n
                break
        
        if not npc:
            return {
                "success": False,
                "error": f"NPC {npc_id} not found in town {town_id}",
                "narrative_summary": "You can't seem to find that person."
            }
        
        # Handle different NPC interactions
        if action == "talk":
            # Generate dialogue based on NPC role and traits
            model_server = get_model_server()
            dialogue_context = {
                "npc": npc,
                "town": town_data,
                "player": game_state.get("player_character", {})
            }
            
            dialogue_response = await model_server.generate_with_json(
                f"Generate dialogue for {npc['name']}, a {npc['trait']} {npc['role']} in {town_data['name']}. "
                f"The dialogue should reflect their personality and role in the town.",
                dialogue_context
            )
            
            dialogue = dialogue_response.get("dialogue", f"{npc['name']} nods at you but doesn't say anything.")
            
            return {
                "success": True,
                "game_state_changes": {},
                "narrative_summary": f"{npc['name']}: \"{dialogue}\""
            }
        
        elif action == "get_quest":
            # Check if NPC has any quests
            quests = npc.get("quests", [])
            available_quests = [q for q in quests if not q.get("completed", False)]
            
            if not available_quests:
                return {
                    "success": True,
                    "game_state_changes": {},
                    "narrative_summary": f"{npc['name']} doesn't have any tasks for you at the moment."
                }
            
            # Select a random quest
            quest = random.choice(available_quests)
            
            narrative = f"{npc['name']} says: \"I need your help with something. {quest['description']}\"\n\n"
            narrative += f"Reward: {quest['reward']} gold coins."
            
            # Add quest to game state if not already there
            game_state_changes = {}
            if "quests" not in game_state:
                game_state_changes["quests"] = []
            
            if quest["id"] not in [q["id"] for q in game_state.get("quests", [])]:
                game_state_changes["quests"] = game_state.get("quests", []) + [{
                    "id": quest["id"],
                    "description": quest["description"],
                    "npc_id": npc["id"],
                    "npc_name": npc["name"],
                    "town_id": town_id,
                    "reward": quest["reward"],
                    "completed": False
                }]
            
            return {
                "success": True,
                "game_state_changes": game_state_changes,
                "narrative_summary": narrative
            }
        
        elif action == "ask_about_town":
            # Generate information about the town from this NPC's perspective
            model_server = get_model_server()
            town_info_context = {
                "npc": npc,
                "town": town_data
            }
            
            town_info_response = await model_server.generate_with_json(
                f"Generate what {npc['name']}, a {npc['trait']} {npc['role']}, would say about {town_data['name']} "
                f"when asked by a visitor. The response should reflect their personality and knowledge of the town.",
                town_info_context
            )
            
            town_info = town_info_response.get("information", f"{npc['name']} doesn't seem to know much about the town.")
            
            return {
                "success": True,
                "game_state_changes": {},
                "narrative_summary": f"{npc['name']} says: \"{town_info}\""
            }
        
        else:
            return {
                "success": False,
                "error": f"Unknown NPC interaction action: {action}",
                "narrative_summary": f"You're not sure how to interact with {npc['name']} that way."
            }
    
    async def _generate_npc(self, request: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a new NPC or retrieve an existing one.
        
        Args:
            request: Generation request details
            game_state: Current game state
            
        Returns:
            Dict containing the generated NPC and game state changes
        """
        npc_id = request.get("npc_id", "")
        location_id = request.get("location_id", "")
        
        # Check if this is a town NPC
        if npc_id and "_" in npc_id:
            parts = npc_id.split("_")
            if len(parts) >= 3 and parts[0] == "npc":
                town_id = parts[1]
                npc_index = parts[2]
                
                # Try to get the NPC from town data
                town_data = None
                if town_id in game_state.get("towns", {}):
                    town_data = game_state["towns"][town_id]
                else:
                    town_data = await self.town_generator.get_or_generate_town(town_id)
                
                if town_data:
                    for npc in town_data["npcs"]:
                        if npc["id"] == npc_id:
                            return {
                                "success": True,
                                "game_state_changes": {},
                                "narrative_summary": f"You see {npc['name']}. {npc['description']}"
                            }
        
        # Generate new NPC using the model
        logger.info(f"Generating new NPC {npc_id} for location {location_id}...")
        
        # Prepare context for the model
        context = {
            "npc_id": npc_id,
            "location_id": location_id,
            "existing_npcs": []
        }
        
        # Add existing NPCs in the location for context
        current_location = game_state.get("current_location", {})
        if current_location.get("npcs"):
            for existing_npc_id in current_location["npcs"]:
                # Try to find the NPC in game state
                for npc in game_state.get("npcs", []):
                    if npc["id"] == existing_npc_id:
                        context["existing_npcs"].append(npc)
                        break
        
        # Generate NPC with the model
        model_server = get_model_server()
        npc_data = await model_server.generate_with_json(
            f"Generate a new NPC with ID {npc_id} for location {location_id}. "
            f"Create a name, description, personality, and possible dialogue. Make them interesting and detailed.",
            context
        )
        
        # Ensure the NPC has all required fields
        if not npc_data.get("name") or not npc_data.get("description"):
            logger.warning(f"Generated NPC {npc_id} is missing required fields.")
            # Create fallback NPC
            npc_data = {
                "id": npc_id,
                "name": f"Stranger {npc_id}",
                "description": "A nondescript person with little to distinguish them.",
                "dialogue": ["Hello there.", "Nice weather, isn't it?", "I don't have much to say."]
            }
        
        # Prepare game state changes
        game_state_changes = {
            "npcs": [npc_data]
        }
        
        # Add NPC to current location if specified
        if location_id:
            if "locations" not in game_state_changes:
                game_state_changes["locations"] = {}
            
            if location_id not in game_state_changes["locations"]:
                game_state_changes["locations"][location_id] = {
                    "id": location_id
                }
            
            if "npcs" not in game_state_changes["locations"][location_id]:
                game_state_changes["locations"][location_id]["npcs"] = []
            
            game_state_changes["locations"][location_id]["npcs"].append(npc_id)
        
        return {
            "success": True,
            "game_state_changes": game_state_changes,
            "narrative_summary": f"You encounter {npc_data['name']}. {npc_data['description']}"
        }
    
    async def _generate_item(self, request: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a new item or retrieve an existing one.
        
        Args:
            request: Generation request details
            game_state: Current game state
            
        Returns:
            Dict containing the generated item and game state changes
        """
        item_id = request.get("item_id", "")
        location_id = request.get("location_id", "")
        item_type = request.get("item_type", "")
        
        # Generate new item using the model
        logger.info(f"Generating new item {item_id} of type {item_type}...")
        
        # Prepare context for the model
        context = {
            "item_id": item_id,
            "location_id": location_id,
            "item_type": item_type
        }
        
        # Generate item with the model
        model_server = get_model_server()
        item_data = await model_server.generate_with_json(
            f"Generate a new item with ID {item_id} of type {item_type}. "
            f"Create a name, description, and properties. Make it interesting and detailed.",
            context
        )
        
        # Ensure the item has all required fields
        if not item_data.get("name") or not item_data.get("description"):
            logger.warning(f"Generated item {item_id} is missing required fields.")
            # Create fallback item
            item_data = {
                "id": item_id,
                "name": f"{item_type.title() if item_type else 'Item'} {item_id}",
                "description": "A nondescript item with little to distinguish it.",
                "type": item_type or "misc"
            }
        
        # Prepare game state changes
        game_state_changes = {
            "items": [item_data]
        }
        
        # Add item to current location if specified
        if location_id:
            if "locations" not in game_state_changes:
                game_state_changes["locations"] = {}
            
            if location_id not in game_state_changes["locations"]:
                game_state_changes["locations"][location_id] = {
                    "id": location_id
                }
            
            if "items" not in game_state_changes["locations"][location_id]:
                game_state_changes["locations"][location_id]["items"] = []
            
            game_state_changes["locations"][location_id]["items"].append(item_id)
        
        return {
            "success": True,
            "game_state_changes": game_state_changes,
            "narrative_summary": f"You find {item_data['name']}. {item_data['description']}"
        }
    
    async def _generate_dialogue(self, request: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate dialogue for an NPC.
        
        Args:
            request: Generation request details
            game_state: Current game state
            
        Returns:
            Dict containing the generated dialogue
        """
        npc_id = request.get("npc_id", "")
        dialogue_type = request.get("dialogue_type", "greeting")
        player_input = request.get("player_input", "")
        
        # Find the NPC
        npc = None
        
        # Check if this is a town NPC
        if npc_id and "_" in npc_id:
            parts = npc_id.split("_")
            if len(parts) >= 3 and parts[0] == "npc":
                town_id = parts[1]
                
                # Try to get the NPC from town data
                town_data = None
                if town_id in game_state.get("towns", {}):
                    town_data = game_state["towns"][town_id]
                else:
                    town_data = await self.town_generator.get_or_generate_town(town_id)
                
                if town_data:
                    for n in town_data["npcs"]:
                        if n["id"] == npc_id:
                            npc = n
                            break
        
        # If not found in town data, check game state
        if not npc:
            for n in game_state.get("npcs", []):
                if n["id"] == npc_id:
                    npc = n
                    break
        
        if not npc:
            return {
                "success": False,
                "error": f"NPC {npc_id} not found",
                "narrative_summary": "You're not sure who to talk to."
            }
        
        # Generate dialogue based on NPC and dialogue type
        logger.info(f"Generating {dialogue_type} dialogue for NPC {npc_id}...")
        
        # Prepare context for the model
        context = {
            "npc": npc,
            "dialogue_type": dialogue_type,
            "player_input": player_input,
            "player_character": game_state.get("player_character", {})
        }
        
        # Generate dialogue with the model
        model_server = get_model_server()
        dialogue_response = await model_server.generate_with_json(
            f"Generate {dialogue_type} dialogue for {npc['name']}. "
            f"The player said: \"{player_input}\". "
            f"The dialogue should reflect the NPC's personality and role.",
            context
        )
        
        dialogue = dialogue_response.get("dialogue", f"{npc['name']} nods but doesn't say anything.")
        
        return {
            "success": True,
            "dialogue": dialogue,
            "narrative_summary": f"{npc['name']} says: \"{dialogue}\""
        }
