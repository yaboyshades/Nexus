"""
Supervisor Agent with Model Protocol Server integration
"""
from typing import Dict, Any, Optional, List
import logging
import json
import asyncio

from agents.base_agent import Agent

class SupervisorAgent(Agent):
    """
    Agent responsible for orchestrating the flow between specialized agents.
    Uses the Model Protocol Server for coordination and decision-making.
    """
    
    def __init__(self, name: str, model_backend: str = None):
        """
        Initialize the Supervisor Agent.
        
        Args:
            name: Agent name
            model_backend: Name of the model backend to use (defaults to server default)
        """
        super().__init__(name, model_backend)
        self.logger.info(f"Supervisor Agent {name} initialized")
        
        # Initialize agent registry
        self.agents = {}
        
        # Initialize game state
        self.game_state = {}
        
        # Define JSON schema for supervisor decisions
        self.decision_schema = {
            "type": "object",
            "properties": {
                "next_step": {"type": "string"},
                "reasoning": {"type": "string"}
            },
            "required": ["next_step"]
        }
    
    def register_agent(self, agent_type: str, agent: Agent) -> None:
        """
        Register a specialized agent with the supervisor.
        
        Args:
            agent_type: Type of agent (intent, rule, narrative, world)
            agent: Agent instance
        """
        self.agents[agent_type] = agent
        self.logger.info(f"Registered {agent_type} agent: {agent.name}")
    
    async def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process player input by orchestrating the flow between specialized agents.
        
        Args:
            input_data: Dictionary containing player_input, user_id, and optionally game_state
            
        Returns:
            Dictionary with response to player
        """
        player_input = input_data.get("player_input", "")
        user_id = input_data.get("user_id", "")
        
        # Update game state if provided
        if "game_state" in input_data:
            self.game_state = input_data["game_state"]
        
        # Initialize response
        response = {
            "response_type": "system_message",
            "message": "Processing your input...",
            "game_state_update": None
        }
        
        try:
            # Step 1: Intent Recognition
            if "intent" not in self.agents:
                return {"error": "Intent Agent not registered"}
            
            intent_input = {
                "player_input": player_input,
                "game_state": self.game_state
            }
            
            intent_result = await self.agents["intent"].process(intent_input)
            
            # Check if intent recognition was successful
            if not intent_result.get("success", False) or intent_result.get("confidence", 0) < 0.5:
                # Intent recognition failed or low confidence
                response["response_type"] = "clarification"
                response["message"] = intent_result.get("message", "I'm not sure what you mean. Could you rephrase that?")
                return response
            
            parsed_intent = intent_result.get("parsed_intent", {})
            
            # Step 2: Rule Application
            if "rule" not in self.agents:
                return {"error": "Rule Agent not registered"}
            
            rule_input = {
                "parsed_intent": parsed_intent,
                "game_state": self.game_state
            }
            
            rule_result = await self.agents["rule"].process(rule_input)
            
            # Update game state with rule changes
            if "game_state_changes" in rule_result and rule_result["game_state_changes"]:
                self._update_game_state(rule_result["game_state_changes"])
            
            # Step 3: World Generation (if needed)
            if rule_result.get("world_generation_needed", False) and "world_generation_request" in rule_result:
                if "world" not in self.agents:
                    return {"error": "World Agent not registered"}
                
                world_input = {
                    "generation_request": rule_result["world_generation_request"],
                    "game_state": self.game_state
                }
                
                world_result = await self.agents["world"].process(world_input)
                
                # Update game state with world generation changes
                if "game_state_changes" in world_result and world_result["game_state_changes"]:
                    self._update_game_state(world_result["game_state_changes"])
            
            # Step 4: Narrative Generation
            if "narrative" not in self.agents:
                return {"error": "Narrative Agent not registered"}
            
            narrative_input = {
                "rule_outcome": rule_result,
                "parsed_intent": parsed_intent,
                "player_input": player_input,
                "game_state": self.game_state
            }
            
            narrative_result = await self.agents["narrative"].process(narrative_input)
            
            # Prepare final response
            response["response_type"] = "narrative"
            response["message"] = narrative_result.get("narrative", rule_result.get("narrative_summary", "Your action is processed."))
            response["game_state_update"] = self._get_frontend_game_state()
            
            # Use the Model Protocol Server to evaluate the response quality
            evaluation_prompt = f"""
            Evaluate the quality of this game response:
            
            Player input: "{player_input}"
            Response: "{response['message']}"
            
            Is this response:
            1. Relevant to the player's input?
            2. Engaging and descriptive?
            3. Consistent with D&D gameplay?
            
            Provide a brief assessment.
            """
            
            evaluation = await self.generate_text(
                prompt=evaluation_prompt,
                params={"temperature": 0.3}
            )
            
            self.logger.info(f"Response evaluation: {evaluation[:100]}...")
            
            return response
            
        except Exception as e:
            self.logger.error(f"Error in supervisor process: {str(e)}")
            return {
                "response_type": "system_message",
                "message": f"An error occurred: {str(e)}",
                "error": str(e)
            }
    
    def _update_game_state(self, changes: Dict[str, Any]) -> None:
        """
        Update the game state with changes.
        
        Args:
            changes: Dictionary of changes to apply
        """
        # Deep merge changes into game state
        for key, value in changes.items():
            if isinstance(value, dict) and key in self.game_state and isinstance(self.game_state[key], dict):
                # Recursively update nested dictionaries
                self._deep_update(self.game_state[key], value)
            else:
                # Direct update for non-dict values or new keys
                self.game_state[key] = value
    
    def _deep_update(self, target: Dict[str, Any], source: Dict[str, Any]) -> None:
        """
        Recursively update a nested dictionary.
        
        Args:
            target: Target dictionary to update
            source: Source dictionary with changes
        """
        for key, value in source.items():
            if isinstance(value, dict) and key in target and isinstance(target[key], dict):
                # Recursively update nested dictionaries
                self._deep_update(target[key], value)
            elif isinstance(value, list) and key in target and isinstance(target[key], list):
                # Special handling for lists - update items by ID if present
                self._update_list_by_id(target[key], value)
            else:
                # Direct update for non-dict values or new keys
                target[key] = value
    
    def _update_list_by_id(self, target_list: List[Dict[str, Any]], source_list: List[Dict[str, Any]]) -> None:
        """
        Update a list of dictionaries by matching IDs.
        
        Args:
            target_list: Target list to update
            source_list: Source list with changes
        """
        for source_item in source_list:
            if "id" in source_item:
                # Find matching item in target list
                target_item = next((item for item in target_list if item.get("id") == source_item["id"]), None)
                
                if target_item:
                    # Update existing item
                    for key, value in source_item.items():
                        if isinstance(value, dict) and key in target_item and isinstance(target_item[key], dict):
                            # Recursively update nested dictionaries
                            self._deep_update(target_item[key], value)
                        else:
                            # Direct update
                            target_item[key] = value
                else:
                    # Add new item
                    target_list.append(source_item)
            else:
                # No ID, just append
                target_list.append(source_item)
    
    def _get_frontend_game_state(self) -> Dict[str, Any]:
        """
        Get a simplified version of the game state for the frontend.
        
        Returns:
            Frontend-friendly game state
        """
        frontend_state = {}
        
        # Include player character info
        if "player_character" in self.game_state:
            frontend_state["player_character"] = {
                "name": self.game_state["player_character"].get("name", ""),
                "race": self.game_state["player_character"].get("race", ""),
                "class": self.game_state["player_character"].get("class", ""),
                "level": self.game_state["player_character"].get("level", 1),
                "hp": self.game_state["player_character"].get("hp", 0),
                "max_hp": self.game_state["player_character"].get("max_hp", 0),
                "ac": self.game_state["player_character"].get("ac", 10),
                "conditions": self.game_state["player_character"].get("conditions", [])
            }
        
        # Include current location info
        if "current_location" in self.game_state:
            frontend_state["current_location"] = {
                "name": self.game_state["current_location"].get("name", ""),
                "description": self.game_state["current_location"].get("description", ""),
                "exits": list(self.game_state["current_location"].get("exits", {}).keys())
            }
        
        # Include combat info if in combat
        frontend_state["in_combat"] = "active_combat" in self.game_state
        if frontend_state["in_combat"]:
            frontend_state["combat"] = {
                "round": self.game_state["active_combat"].get("round", 1),
                "current_turn": self.game_state["active_combat"].get("current_turn", "")
            }
        
        return frontend_state
    
    async def decide_next_step(self, current_state: Dict[str, Any], available_actions: List[str]) -> str:
        """
        Use the Model Protocol Server to decide the next processing step.
        
        Args:
            current_state: Current processing state
            available_actions: List of available next actions
            
        Returns:
            Next action to take
        """
        prompt = f"""
        You are the supervisor for a D&D game engine. Decide the next processing step based on the current state.
        
        Current state:
        {json.dumps(current_state, indent=2)}
        
        Available actions:
        {', '.join(available_actions)}
        
        Which action should be taken next? Consider:
        - The logical flow of processing
        - Dependencies between steps
        - Efficiency of processing
        
        Respond with a JSON object containing:
        - next_step: The next action to take
        - reasoning: Brief explanation of why this action was chosen
        """
        
        response = await self.generate_json(
            prompt=prompt,
            json_schema=self.decision_schema,
            params={"temperature": 0.3}
        )
        
        return response.get("next_step", available_actions[0])
