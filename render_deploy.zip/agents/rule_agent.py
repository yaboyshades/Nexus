"""
Rule Agent with Model Protocol Server integration
"""
from typing import Dict, Any, Optional, List
import logging
import json
import random

from agents.base_agent import Agent

class RuleAgent(Agent):
    """
    Agent responsible for applying D&D 5e rules to player actions.
    Uses the Model Protocol Server to process game mechanics and state changes.
    """
    
    def __init__(self, name: str, model_backend: str = None):
        """
        Initialize the Rule Agent.
        
        Args:
            name: Agent name
            model_backend: Name of the model backend to use (defaults to server default)
        """
        super().__init__(name, model_backend)
        self.logger.info(f"Rule Agent {name} initialized")
        
        # Define JSON schema for rule resolution responses
        self.rule_schema = {
            "type": "object",
            "properties": {
                "success": {"type": "boolean"},
                "narrative_summary": {"type": "string"},
                "game_state_changes": {
                    "type": "object",
                    "additionalProperties": True
                },
                "new_events": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "type": {"type": "string"},
                            "additionalProperties": True
                        }
                    }
                },
                "world_generation_needed": {"type": "boolean"},
                "world_generation_request": {
                    "type": "object",
                    "additionalProperties": True
                }
            },
            "required": ["success", "narrative_summary"]
        }
    
    async def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process player intent and apply game rules.
        
        Args:
            input_data: Dictionary containing parsed_intent and game_state
            
        Returns:
            Dictionary with rule resolution results
        """
        parsed_intent = input_data.get("parsed_intent", {})
        game_state = input_data.get("game_state", {})
        
        if not parsed_intent:
            return {
                "success": False,
                "narrative_summary": "No intent provided."
            }
        
        action = parsed_intent.get("action", "")
        
        # Create prompt for the model based on the action
        prompt = self._create_rule_prompt(parsed_intent, game_state)
        
        # Generate JSON response using the model protocol server
        response = await self.generate_json(
            prompt=prompt,
            json_schema=self.rule_schema,
            params={"temperature": 0.4}  # Moderate temperature for rule application
        )
        
        # Ensure required fields are present
        if "success" not in response:
            response["success"] = False
        if "narrative_summary" not in response:
            response["narrative_summary"] = "The action was processed."
        if "game_state_changes" not in response:
            response["game_state_changes"] = {}
        if "new_events" not in response:
            response["new_events"] = []
        
        # Add default values for world generation
        if "world_generation_needed" not in response:
            response["world_generation_needed"] = False
        
        # Apply any dice roll logic that needs to be handled locally
        response = self._process_dice_rolls(response, parsed_intent, game_state)
        
        # Log the result
        self.logger.info(f"Rule resolution for {action}: {response['success']}")
        
        return response
    
    def _create_rule_prompt(self, parsed_intent: Dict[str, Any], game_state: Dict[str, Any]) -> str:
        """
        Create a prompt for rule application.
        
        Args:
            parsed_intent: Parsed player intent
            game_state: Current game state
            
        Returns:
            Formatted prompt for the model
        """
        action = parsed_intent.get("action", "")
        
        # Extract relevant context from game state
        current_location = game_state.get("current_location", {})
        location_name = current_location.get("name", "unknown location")
        
        # Get player character info
        player_character = game_state.get("player_character", {})
        pc_name = player_character.get("name", "the player")
        pc_hp = player_character.get("hp", 0)
        pc_max_hp = player_character.get("max_hp", 0)
        pc_attack_bonus = player_character.get("attack_bonus", 0)
        pc_damage_dice = player_character.get("damage_dice", "1d6")
        pc_damage_bonus = player_character.get("damage_bonus", 0)
        
        # Build the base prompt
        prompt = f"""You are a D&D 5e rule engine. Apply game rules to resolve the player's action.

Current location: {location_name}
Player character: {pc_name} (HP: {pc_hp}/{pc_max_hp}, Attack bonus: +{pc_attack_bonus}, Damage: {pc_damage_dice}+{pc_damage_bonus})

Player intent: {json.dumps(parsed_intent)}

Current game state: {json.dumps(game_state, indent=2)}

Apply D&D 5e rules to resolve this action. Consider:
- Success or failure of the action
- Any dice rolls needed (attack rolls, damage, skill checks)
- Changes to game state (HP, inventory, location, etc.)
- Any new events triggered by the action
- Whether world generation is needed (e.g., for new locations)

Respond with a JSON object containing:
- success: boolean indicating if the action was successful
- narrative_summary: brief description of what happened
- game_state_changes: object with changes to apply to the game state
- new_events: array of event objects triggered by the action
- world_generation_needed: boolean indicating if world generation is needed
- world_generation_request: object with details for world generation (if needed)
"""
        
        # Add action-specific instructions
        if action == "attack":
            target_name = parsed_intent.get("target_name", "the target")
            prompt += f"\nThis is an attack action against {target_name}. Apply combat rules including:\n"
            prompt += "- Roll d20 + attack bonus vs target AC\n"
            prompt += "- On hit, roll damage dice + damage bonus\n"
            prompt += "- Update target HP\n"
            prompt += "- Check if target is defeated\n"
        
        elif action == "cast_spell":
            spell_name = parsed_intent.get("spell_name", "the spell")
            target_name = parsed_intent.get("target_name", "the target")
            prompt += f"\nThis is a spell casting action ({spell_name}) targeting {target_name}. Apply spell rules including:\n"
            prompt += "- Check if player knows the spell\n"
            prompt += "- Apply spell effects based on spell type\n"
            prompt += "- Roll any required dice for the spell\n"
            prompt += "- Update game state based on spell effects\n"
        
        elif action == "move":
            direction = parsed_intent.get("direction", "unknown direction")
            prompt += f"\nThis is a movement action in direction: {direction}. Apply movement rules including:\n"
            prompt += "- Check if the direction is a valid exit\n"
            prompt += "- Update player location\n"
            prompt += "- Determine if world generation is needed for new locations\n"
        
        elif action == "examine":
            target_name = parsed_intent.get("target_name", "the surroundings")
            prompt += f"\nThis is an examination action for {target_name}. Apply rules including:\n"
            prompt += "- Gather information about the target\n"
            prompt += "- Reveal any hidden details based on perception\n"
        
        elif action == "talk":
            target_name = parsed_intent.get("target_name", "the NPC")
            prompt += f"\nThis is a dialogue action with {target_name}. Apply rules including:\n"
            prompt += "- Check if the NPC is present and can be talked to\n"
            prompt += "- Determine appropriate dialogue options\n"
            prompt += "- Update NPC relationship status if relevant\n"
        
        elif action == "pick_up_item":
            item_name = parsed_intent.get("target_name", "the item")
            prompt += f"\nThis is an item pickup action for {item_name}. Apply rules including:\n"
            prompt += "- Check if the item is present and can be picked up\n"
            prompt += "- Add item to player inventory\n"
            prompt += "- Remove item from current location\n"
        
        elif action == "help":
            prompt += "\nThis is a help request. Provide information about available commands and game mechanics.\n"
        
        return prompt
    
    def _process_dice_rolls(self, response: Dict[str, Any], parsed_intent: Dict[str, Any], game_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process any dice rolls needed for the action.
        
        Args:
            response: Initial response from the model
            parsed_intent: Parsed player intent
            game_state: Current game state
            
        Returns:
            Updated response with dice roll results
        """
        action = parsed_intent.get("action", "")
        
        # For attack actions, we might want to handle the actual dice rolling locally
        if action == "attack" and response.get("success"):
            # Get target information
            target_id = parsed_intent.get("target_id")
            if not target_id:
                return response
            
            # Find target in game state
            current_location = game_state.get("current_location", {})
            monsters = current_location.get("monsters", [])
            target = next((m for m in monsters if m.get("id") == target_id), None)
            
            if not target:
                return response
            
            # Get player character info
            player_character = game_state.get("player_character", {})
            attack_bonus = player_character.get("attack_bonus", 0)
            damage_dice = player_character.get("damage_dice", "1d6")
            damage_bonus = player_character.get("damage_bonus", 0)
            
            # Roll attack
            attack_roll = random.randint(1, 20)
            attack_total = attack_roll + attack_bonus
            
            # Get target AC
            target_ac = target.get("ac", 10)
            
            # Check if hit
            hit = attack_roll == 20 or attack_total >= target_ac
            
            if hit:
                # Parse damage dice (e.g., "2d6")
                dice_parts = damage_dice.split("d")
                if len(dice_parts) == 2:
                    num_dice = int(dice_parts[0])
                    dice_size = int(dice_parts[1])
                    
                    # Roll damage
                    damage = sum(random.randint(1, dice_size) for _ in range(num_dice))
                    if attack_roll == 20:  # Critical hit
                        damage *= 2
                    
                    damage += damage_bonus
                    
                    # Update target HP
                    target_hp = target.get("hp", 0)
                    new_hp = max(0, target_hp - damage)
                    
                    # Update response
                    if "game_state_changes" not in response:
                        response["game_state_changes"] = {}
                    if "current_location" not in response["game_state_changes"]:
                        response["game_state_changes"]["current_location"] = {}
                    if "monsters" not in response["game_state_changes"]["current_location"]:
                        response["game_state_changes"]["current_location"]["monsters"] = []
                    
                    # Add updated monster
                    response["game_state_changes"]["current_location"]["monsters"].append({
                        "id": target_id,
                        "hp": new_hp
                    })
                    
                    # Update narrative summary
                    crit_text = " (Critical Hit!)" if attack_roll == 20 else ""
                    response["narrative_summary"] = f"You hit with a {attack_total} against AC {target_ac}{crit_text}, dealing {damage} damage."
                    
                    # Check if monster defeated
                    if new_hp == 0:
                        response["narrative_summary"] += f" {target.get('name', 'The target')} is defeated!"
                        
                        # Add defeat event
                        if "new_events" not in response:
                            response["new_events"] = []
                        
                        response["new_events"].append({
                            "type": "MonsterDefeated",
                            "monster_id": target_id,
                            "xp_amount": target.get("xp_value", 0)
                        })
            else:
                # Miss
                response["narrative_summary"] = f"You miss with a {attack_total} against AC {target_ac}."
        
        return response
