"""
Narrative Agent with Model Protocol Server integration
"""
from typing import Dict, Any, Optional, List
import logging
import json
import random

from agents.base_agent import Agent

class NarrativeAgent(Agent):
    """
    Agent responsible for generating narrative descriptions and dialogue.
    Uses the Model Protocol Server to create immersive storytelling content.
    """
    
    def __init__(self, name: str, model_backend: str = None):
        """
        Initialize the Narrative Agent.
        
        Args:
            name: Agent name
            model_backend: Name of the model backend to use (defaults to server default)
        """
        super().__init__(name, model_backend)
        self.logger.info(f"Narrative Agent {name} initialized")
        
        # Define JSON schema for narrative generation responses
        self.narrative_schema = {
            "type": "object",
            "properties": {
                "narrative": {"type": "string"}
            },
            "required": ["narrative"]
        }
        
        # Initialize flavor text options
        self._initialize_flavor_text()
    
    def _initialize_flavor_text(self):
        """Initialize flavor text options for different narrative situations"""
        self.attack_flavor = [
            "The strike lands with devastating force.",
            "Your weapon finds a gap in the enemy's defenses.",
            "A precise blow that leaves your opponent reeling.",
            "The attack connects with a satisfying impact.",
            "Your combat training pays off with a well-placed strike."
        ]
        
        self.miss_flavor = [
            "Your attack narrowly misses its mark.",
            "The enemy deftly evades your strike.",
            "Your weapon whistles through empty air.",
            "The timing of your attack is just slightly off.",
            "Your opponent manages to deflect the blow at the last moment."
        ]
        
        self.spell_flavor = [
            "Arcane energy crackles around your fingertips as you cast.",
            "The air shimmers with magical potential as you invoke the spell.",
            "Ancient words of power echo as you complete the incantation.",
            "The spell's energy courses through you and manifests with precision.",
            "Reality bends slightly to your will as the spell takes form."
        ]
        
        self.movement_flavor = [
            "You proceed cautiously, taking in your new surroundings.",
            "You make your way forward, alert for any signs of danger.",
            "With careful steps, you navigate to the new area.",
            "You advance, your senses heightened to the unfamiliar environment.",
            "You move with purpose, scanning the area as you go."
        ]
    
    async def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process rule outcomes and generate narrative descriptions.
        
        Args:
            input_data: Dictionary containing rule_outcome, parsed_intent, player_input, and game_state
            
        Returns:
            Dictionary with narrative text
        """
        rule_outcome = input_data.get("rule_outcome", {})
        parsed_intent = input_data.get("parsed_intent", {})
        player_input = input_data.get("player_input", "")
        game_state = input_data.get("game_state", {})
        
        if not rule_outcome:
            return {
                "narrative": "The Dungeon Master ponders your action..."
            }
        
        # Create prompt for the model
        prompt = self._create_narrative_prompt(rule_outcome, parsed_intent, player_input, game_state)
        
        # Generate JSON response using the model protocol server
        response = await self.generate_json(
            prompt=prompt,
            json_schema=self.narrative_schema,
            params={"temperature": 0.7}  # Higher temperature for creative narrative
        )
        
        # Ensure required fields are present
        if "narrative" not in response:
            # Use rule outcome summary as fallback
            response["narrative"] = rule_outcome.get("narrative_summary", "The action is resolved.")
            
            # Add some flavor text based on the action
            action = parsed_intent.get("action", "")
            if action == "attack":
                if "hit" in rule_outcome.get("narrative_summary", "").lower():
                    response["narrative"] += " " + random.choice(self.attack_flavor)
                elif "miss" in rule_outcome.get("narrative_summary", "").lower():
                    response["narrative"] += " " + random.choice(self.miss_flavor)
            elif action == "cast_spell":
                response["narrative"] += " " + random.choice(self.spell_flavor)
            elif action == "move":
                response["narrative"] += " " + random.choice(self.movement_flavor)
        
        # Log the result
        self.logger.info(f"Generated narrative for {parsed_intent.get('action', 'action')}")
        
        return response
    
    def _create_narrative_prompt(self, rule_outcome: Dict[str, Any], parsed_intent: Dict[str, Any], player_input: str, game_state: Dict[str, Any]) -> str:
        """
        Create a prompt for narrative generation.
        
        Args:
            rule_outcome: Result of rule application
            parsed_intent: Parsed player intent
            player_input: Raw player input text
            game_state: Current game state
            
        Returns:
            Formatted prompt for the model
        """
        action = parsed_intent.get("action", "")
        narrative_summary = rule_outcome.get("narrative_summary", "")
        
        # Extract relevant context from game state
        current_location = game_state.get("current_location", {})
        location_name = current_location.get("name", "unknown location")
        location_desc = current_location.get("description", "")
        
        # Get player character info
        player_character = game_state.get("player_character", {})
        pc_name = player_character.get("name", "the player")
        
        # Build the prompt
        prompt = f"""You are a narrative generator for a D&D game. Create an immersive, descriptive narrative based on the player's action and the outcome.

Location: {location_name}
Location description: {location_desc}
Player character: {pc_name}

Player input: "{player_input}"
Player intent: {json.dumps(parsed_intent)}
Rule outcome: {json.dumps(rule_outcome)}

Generate a vivid, engaging narrative description of what happens. Use sensory details, emotional elements, and environmental context to make the scene come alive. The narrative should be in second person perspective (addressing the player as "you").

Your narrative should:
- Be 2-3 sentences long
- Include relevant details from the rule outcome
- Match the tone of a D&D game (heroic fantasy)
- Be consistent with the game state
- Avoid introducing new facts not supported by the game state
"""
        
        # Add action-specific instructions
        if action == "attack":
            target_name = parsed_intent.get("target_name", "the target")
            hit = "hit" in narrative_summary.lower()
            
            prompt += f"\nThis is an attack action against {target_name}. "
            if hit:
                prompt += "Describe the successful attack, the impact, and the target's reaction."
            else:
                prompt += "Describe the missed attack and why it failed to connect."
        
        elif action == "cast_spell":
            spell_name = parsed_intent.get("spell_name", "the spell")
            target_name = parsed_intent.get("target_name", "the target")
            
            prompt += f"\nThis is a spell casting action ({spell_name}) targeting {target_name}. "
            prompt += "Describe the magical energies, the spell's effects, and the impact on the target or environment."
        
        elif action == "move":
            direction = parsed_intent.get("direction", "unknown direction")
            
            prompt += f"\nThis is a movement action in direction: {direction}. "
            prompt += "Describe the journey and the player's first impressions of the new location."
        
        elif action == "examine":
            target_name = parsed_intent.get("target_name", "the surroundings")
            
            prompt += f"\nThis is an examination action for {target_name}. "
            prompt += "Describe what the player notices, focusing on details that might be important or interesting."
        
        elif action == "talk":
            target_name = parsed_intent.get("target_name", "the NPC")
            
            prompt += f"\nThis is a dialogue action with {target_name}. "
            prompt += "Include the NPC's response, tone, body language, and any relevant background context."
        
        return prompt
