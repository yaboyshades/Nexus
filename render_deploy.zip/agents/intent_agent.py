"""
Intent Agent with Model Protocol Server integration
"""
from typing import Dict, Any, Optional, List
import logging
import json

from agents.base_agent import Agent

class IntentAgent(Agent):
    """
    Agent responsible for understanding player intent from natural language input.
    Uses the Model Protocol Server to process player commands and extract structured intent.
    """
    
    def __init__(self, name: str, model_backend: str = None):
        """
        Initialize the Intent Agent.
        
        Args:
            name: Agent name
            model_backend: Name of the model backend to use (defaults to server default)
        """
        super().__init__(name, model_backend)
        self.logger.info(f"Intent Agent {name} initialized")
        
        # Define JSON schema for intent parsing responses
        self.intent_schema = {
            "type": "object",
            "properties": {
                "success": {"type": "boolean"},
                "confidence": {"type": "number"},
                "parsed_intent": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string"},
                        "target_id": {"type": "string"},
                        "target_name": {"type": "string"},
                        "direction": {"type": "string"},
                        "spell_id": {"type": "string"},
                        "spell_name": {"type": "string"},
                        "parameters": {"type": "object"}
                    }
                },
                "message": {"type": "string"}
            },
            "required": ["success", "confidence"]
        }
    
    async def process(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process player input to determine intent.
        
        Args:
            input_data: Dictionary containing player_input and game_state
            
        Returns:
            Dictionary with parsed intent information
        """
        player_input = input_data.get("player_input", "")
        game_state = input_data.get("game_state", {})
        
        if not player_input:
            return {
                "success": False,
                "confidence": 0.0,
                "message": "No player input provided."
            }
        
        # Create prompt for the model
        prompt = self._create_intent_prompt(player_input, game_state)
        
        # Generate JSON response using the model protocol server
        response = await self.generate_json(
            prompt=prompt,
            json_schema=self.intent_schema,
            params={"temperature": 0.3}  # Lower temperature for more deterministic parsing
        )
        
        # Ensure required fields are present
        if not response.get("success", False):
            response["success"] = False
        if "confidence" not in response:
            response["confidence"] = 0.0
        if "message" not in response and not response.get("success"):
            response["message"] = "Failed to parse intent."
        
        # Log the result
        self.logger.info(f"Parsed intent: {json.dumps(response.get('parsed_intent', {}))}")
        
        return response
    
    def _create_intent_prompt(self, player_input: str, game_state: Dict[str, Any]) -> str:
        """
        Create a prompt for intent parsing.
        
        Args:
            player_input: Raw player input text
            game_state: Current game state
            
        Returns:
            Formatted prompt for the model
        """
        # Extract relevant context from game state
        current_location = game_state.get("current_location", {})
        location_name = current_location.get("name", "unknown location")
        
        # Get available targets in the current location
        npcs = current_location.get("npcs", [])
        npc_names = [npc.get("name", "") for npc in npcs]
        
        monsters = current_location.get("monsters", [])
        monster_names = [monster.get("name", "") for monster in monsters]
        
        items = current_location.get("items", [])
        item_names = [item.get("name", "") for item in items]
        
        exits = current_location.get("exits", {})
        directions = list(exits.keys())
        
        # Get player character info
        player_character = game_state.get("player_character", {})
        known_spells = player_character.get("known_spells", [])
        spell_names = [spell.get("name", "") for spell in known_spells]
        
        # Build the prompt
        prompt = f"""You are an intent recognition system for a D&D game. Parse the player's input to determine their intent.

Current location: {location_name}
Available NPCs: {', '.join(npc_names) if npc_names else 'none'}
Visible monsters: {', '.join(monster_names) if monster_names else 'none'}
Visible items: {', '.join(item_names) if item_names else 'none'}
Available exits: {', '.join(directions) if directions else 'none'}
Known spells: {', '.join(spell_names) if spell_names else 'none'}

Player input: "{player_input}"

Identify the player's intent and extract structured information. Common intents include:
- attack: When the player wants to attack a target
- move: When the player wants to move in a direction
- examine: When the player wants to look at something
- talk: When the player wants to talk to an NPC
- pick_up_item: When the player wants to pick up an item
- cast_spell: When the player wants to cast a spell
- help: When the player asks for help
- general: For other actions not covered above

Respond with a JSON object containing:
- success: boolean indicating if intent was successfully parsed
- confidence: number between 0 and 1 indicating confidence in the parsing
- parsed_intent: object containing action, target_id, target_name, direction, spell_id, spell_name, and parameters
- message: error message if parsing failed

For targets, try to match them to the available NPCs, monsters, or items in the current location.
For directions, match to available exits.
For spells, match to known spells.
"""
        
        return prompt
    
    def _extract_target(self, target_name: str, game_state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Extract target information from game state based on name.
        
        Args:
            target_name: Name of the target
            game_state: Current game state
            
        Returns:
            Target information or None if not found
        """
        if not target_name:
            return None
        
        current_location = game_state.get("current_location", {})
        
        # Check NPCs
        for npc in current_location.get("npcs", []):
            if target_name.lower() in npc.get("name", "").lower():
                return {"id": npc.get("id"), "name": npc.get("name")}
        
        # Check monsters
        for monster in current_location.get("monsters", []):
            if target_name.lower() in monster.get("name", "").lower():
                return {"id": monster.get("id"), "name": monster.get("name")}
        
        # Check items
        for item in current_location.get("items", []):
            if target_name.lower() in item.get("name", "").lower():
                return {"id": item.get("id"), "name": item.get("name")}
        
        return None
    
    def _extract_spell(self, spell_name: str, game_state: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Extract spell information from game state based on name.
        
        Args:
            spell_name: Name of the spell
            game_state: Current game state
            
        Returns:
            Spell information or None if not found
        """
        if not spell_name:
            return None
        
        player_character = game_state.get("player_character", {})
        
        # Check known spells
        for spell in player_character.get("known_spells", []):
            if spell_name.lower() in spell.get("name", "").lower():
                return {"id": spell.get("id"), "name": spell.get("name")}
        
        return None
    
    def _extract_direction(self, direction: str, game_state: Dict[str, Any]) -> Optional[str]:
        """
        Extract direction information from game state.
        
        Args:
            direction: Direction string
            game_state: Current game state
            
        Returns:
            Validated direction or None if not valid
        """
        if not direction:
            return None
        
        current_location = game_state.get("current_location", {})
        exits = current_location.get("exits", {})
        
        # Normalize direction
        direction = direction.lower()
        
        # Check if direction is valid
        if direction in exits:
            return direction
        
        # Check for direction aliases
        direction_aliases = {
            "n": "north",
            "s": "south",
            "e": "east",
            "w": "west",
            "ne": "northeast",
            "nw": "northwest",
            "se": "southeast",
            "sw": "southwest",
            "u": "up",
            "d": "down"
        }
        
        if direction in direction_aliases and direction_aliases[direction] in exits:
            return direction_aliases[direction]
        
        return None
