"""
Chronicle Weave - Utility Functions
"""
