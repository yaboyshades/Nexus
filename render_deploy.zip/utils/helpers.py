import logging
from typing import Dict, Any, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger('chronicle_weave')

def setup_logger():
    """Set up and return the logger."""
    return logger

def dice_roll(dice_str: str) -> int:
    """
    Roll dice based on standard dice notation (e.g., "2d6+3").
    
    Args:
        dice_str: String in dice notation format
        
    Returns:
        Result of the dice roll
    """
    import random
    import re
    
    # Parse dice string
    match = re.match(r'(\d+)d(\d+)(?:([\+\-])(\d+))?', dice_str.lower())
    if not match:
        logger.error(f"Invalid dice format: {dice_str}")
        return 0
    
    num_dice = int(match.group(1))
    sides = int(match.group(2))
    
    # Roll dice
    total = sum(random.randint(1, sides) for _ in range(num_dice))
    
    # Apply modifier if present
    if match.group(3) and match.group(4):
        modifier = int(match.group(4))
        if match.group(3) == '+':
            total += modifier
        else:
            total -= modifier
    
    return total

def deep_merge(source: Dict[str, Any], destination: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deep merge two dictionaries.
    
    Args:
        source: Source dictionary
        destination: Destination dictionary
        
    Returns:
        Merged dictionary
    """
    for key, value in source.items():
        if isinstance(value, dict) and key in destination and isinstance(destination[key], dict):
            destination[key] = deep_merge(value, destination[key])
        else:
            destination[key] = value
    return destination

def generate_id(prefix: str = "") -> str:
    """
    Generate a unique ID.
    
    Args:
        prefix: Optional prefix for the ID
        
    Returns:
        Unique ID string
    """
    import uuid
    return f"{prefix}_{uuid.uuid4()}"
